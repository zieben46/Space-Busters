package jig.misc.graph;


/**
 * An edge connects two nodes in a graph. The edge connects the <code>source</code>
 * to the <code>destination</code> for a specific cost (which may be infinite).
 * 
 * @author Scott Wallace
 *
 * @param <N> the type of <code>Node</code> connected by this edge
 */
public interface Edge<N extends Node> {

	/**
	 * @return the source (starting node) of this edge
	 */
	N getSource();
	/**
	 * @return the destination (ending node) of this edge
	 */
	N getDestination();
	
	/**
	 * @return the cost of traversing/using this edge (possibly infinite)
	 */
	double getCost();
}
