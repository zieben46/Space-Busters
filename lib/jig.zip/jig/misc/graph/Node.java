package jig.misc.graph;

/**
 * A Node in a graph. These must be comparable to one another.
 * 
 * @author Scott Wallace
 *
 */
public interface Node extends Comparable<Node>{

}
