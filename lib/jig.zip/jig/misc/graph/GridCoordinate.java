package jig.misc.graph;

import jig.engine.util.Vector2D;

/**
 * A Node in a Grid. A GridCoordinate has 
 * x and y values that can be used to uniquely identify its location in the
 * graph. 
 * 
 * 
 * @author Scott Wallace
 *
 * @see Grid
 */
public class GridCoordinate implements Node {
	private int gx, gy;
	private double worldX, worldY;
	private int hash;
	
	/**
	 * Creates a new GridCoordinate belonging to the specified grid
	 * 
	 * @param gx
	 * @param gy
	 * @param grid
	 */
	public GridCoordinate(int gx, int gy, Grid grid) {
		this.gx = gx;
		this.gy = gy;
		Vector2D spot = grid.gridToWorld(new Vector2D(gx, gy));
		this.worldX = spot.getX();
		this.worldY = spot.getY();
		this.hash = hashOf(gx, gy, grid);
	}
	/**
	 * @return the x coordinate of the node in the grid-coordinate system
	 */
	public int getGridX() {return gx;}
	/**
	 * @return the y coordinate of the node in the grid-coordinate system
	 */
	public int getGridY() {return gy;}
	/**
	 * @return the x coordinate of the node in the world coordinate system
	 * after applying any transform function from the grid itself.
	 */
	public double getWorldX() { return worldX; }

	/**
	 * @return the y coordinate of the node in the world coordinate system
	 * after applying any transform function from the grid itself.
	 */
	public double getWorldY() { return worldY; }
	
	/**
	 * Computes the hashCode of a GridCoordinate without requiring the
	 * creation of the object itself.  This method can be used to lookup 
	 * singleton instances from a table, for example.
	 * 
	 * @param gx the x coordinate of the node in grid coordinates
	 * @param gy the y coordinate of the node in grid coordinates
	 * @param g the grid to which this node belongs
	 * @return the hash code of the object created with these same parameters
	 */
	public static int hashOf(int gx, int gy, Grid g) {
		return gy * g.gWidth + gx;
	}
	
	/**
	 * @return <code>true</code> if the objects refer to the same location
	 * in the same grid.
	 */
 	@Override
	public boolean equals(Object o) {
		if (!(o instanceof GridCoordinate)) return false;
		GridCoordinate gc = (GridCoordinate)o;
		return (gc.hash == hash && gc.gy == gy && gc.gx == gx);
	}
 	/**
 	 * {@inheritDoc}
 	 */
	@Override
	public int hashCode() { return hash; }

	/**
	 * {@inheritDoc}
	 */
	public int compareTo(Node o) {
		GridCoordinate gc = (GridCoordinate)o;
		if (hash < gc.hash) return -1;
		if (hash > gc.hash) return 1;
		return 0;
	}

	@Override
	public String toString() {
		return "(" + gx + "," + gy + ")";
	}
}
