package jig.misc.graph;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jig.engine.ResourceFactory;
import jig.engine.util.Vector2D;


/**
 * A Grid is a graph in which the nodes are regularly spaced and can
 * be uniquely identified by their two dimensional coordinates. A chess
 * board is a good example of such a grid, where nodes correspond to 
 * squares on the board.
 * 
 * A grid is easily visualized since the grid coordinate system can simply
 * be transformed into screen coordinates with a suitable affine transformation.
 * 
 * Grids typically are regular in the following senses: 1) they are usually
 * rectangular; and 2) they are usually planar. Although these properties
 * typically hold, they are not prerequisite.
 * 
 * 
 * @author Scott Wallace
 *
 */
public abstract class Grid implements EnumerableGraph<GridCoordinate>{
	
	
	
	/** A transform for changing between grid and world coordinates 
	 * (the inverse of <code>screenToGridAffineTransform</code>). */
	private double[] gridToWorldAffineTransform = {1.0, 0.0, 0.0, 1.0, 0.0, 0.0};

	/** A transform for changing between world and grid coordinates 
	 * (the inverse of <code>gridToScreenAffineTransform</code>). */
	private double[] worldToGridAffineTransform = {1.0, 0.0, 0.0, 1.0, 0.0, 0.0};

	/** the height in grid coordinates. */
	protected int gHeight;
	
	/** the width in grid coordinates. */
	protected int gWidth;
	
	/**
	 * An immutable store of all the nodes in the grid. 
	 */
	protected List<GridCoordinate> nodes;
	
	
	/**
	 * @return a list of all the edges in the grid.
	 */
	public abstract List<Edge<GridCoordinate>> getEdges(GridCoordinate gc);
	
	/**
	 * @return a list of all the nodes (cells) in the grid. 
	 */
	public List<GridCoordinate> getNodes() {
		if (nodes == null) {
			nodes = new ArrayList<GridCoordinate>(gWidth*gHeight);
			for (int y = 0; y < gHeight; y++) {
				for (int x = 0; x < gWidth; x++) {
					nodes.add(null);
				}
			}
			for (int y = 0; y < gHeight; y++) {
				for (int x = 0; x < gWidth; x++) {
					nodes.set(GridCoordinate.hashOf(x,y,this), new GridCoordinate(x,y,this));
				}
			}
		
			nodes = Collections.unmodifiableList(nodes);

		}
		return nodes;
	}

	/**
	 * Gets a node from using its unique 2-dimensional grid coordinates.
	 * @param gx the x grid coordinate of the desired node
	 * @param gy the y grid coordinate of the desired node
	 * @return the node associated with this coordinate or <code>null</code>
	 * if no such node exists.
	 */
	public GridCoordinate getNode(int gx, int gy) {
		if (gx < 0 || gx >= gWidth || gy < 0 || gy >= gHeight)
			return null;
		
		return getNodes().get(gy*gWidth + gx);
	}
	/**
	 *  A grid is dense in that range of hashkeys and the maximum hashkey 
	 *  associated with the node objects is bounded by the number of nodes. 
	 *  So, it makes sense to hash directly into an array as opposed to 
	 *  a real hashtable.
	*  @return <code>true</code>
	 */
	public boolean denseNodes() { return true; }
	
	/**
	 * The maximum hashkey returned by any node in this graph.
	 * @return the number of cells in the grid.
	 */
	public int maxNodeHash() { return gHeight*gWidth; }

	/**
	 * Sets the transform between grid coordinates and world coordinates and 
	 * vice versa.
	 * 
	 * @param an invertable affine transform
	 */
	public void setGridToWorldTransform(AffineTransform at) {
			try {
				AffineTransform bt = at.createInverse();
				at.getMatrix(gridToWorldAffineTransform);
				bt.getMatrix(worldToGridAffineTransform);
			} catch (NoninvertibleTransformException e) {
				ResourceFactory.getJIGLogger().warning("Cannot invert matrix");
			}
	}

	/**
	 * Computes world coordinates from grid coordinates.
	 * Integer values occur on the upper-left corner of an unskewed grid.
	 * @param g the grid coordinates passed in as a Vector2D
	 * @return the screen coordinate as a Vector2D
	 */
	public Vector2D gridToWorld(Vector2D g) {
		double x = (g.getX() * gridToWorldAffineTransform[0] + 
			    g.getY() * gridToWorldAffineTransform[2] + 
			    gridToWorldAffineTransform[4]);
		double y = (g.getX() * gridToWorldAffineTransform[1] + 
			    g.getY() * gridToWorldAffineTransform[3] + 
			    gridToWorldAffineTransform[5]);
		return new Vector2D(x,y);
	}
			
	/**
	 * Computes grid coordinates from world coordinates.
	 * @param g the world coordinates passed in as a Vector2D
	 * @return the grid coordinates as a Vector2D
	 */
	public Vector2D worldToGrid(Vector2D s)
	{
		int x = (int)((s.getX() * worldToGridAffineTransform[0]) + 
				(s.getY() * worldToGridAffineTransform[2]) +
				worldToGridAffineTransform[4]);
		int y = (int) ((s.getX() * worldToGridAffineTransform[1]) + 
			(s.getY() * worldToGridAffineTransform[3]) +
			worldToGridAffineTransform[5]);
		
		return new Vector2D(x,y);
	}

	/**
	 * 
	 * @return the width of the grid in grid coordinates.
	 */
	public int getGridWidth() { return gWidth; }
	
	/**
	 * @return the height of the grid in grid coordinates.	 
	 */
	public int getGridHeight() { return gHeight; }
}



