package jig.misc.graph;

import java.util.List;


/**
 * A generic graph structure containing nodes connected by edges.
 * 
 * By "Enumerable", we mean that it is reasonable to enumerate
 * the nodes in this graph (e.g., through a call to 
 * <code>getNodes()</code>).
 * 
 * 
 * @author Scott Wallace
 *
 * @param <N> the type of <code>Node</code> used in this graph.
 */
public interface EnumerableGraph<N extends Node> {

	/**
	 * Gets the set of edges flowing out of the specified node.
	 * @param node a node graph which will be the source of all edges returned
	 * @return all edges connecting the specified nodes to other nodes in the graph
	 */
	List<Edge<N>> getEdges(N node);

	/**
	 * Gets a list of all the nodes in this graph. This method puts a fundamental
	 * limit on the size of the graph that is reasonable to represent.
	 * 
	 * @return all nodes in the graph.
	 */
	List<N> getNodes();
	
	/**
	 * @return <code>true</code> iff the hash code's for the nodes in this graph
	 * are dense. In other words, iff it makes sense to store nodes in an array
	 * with direct lookup.
	 * 
	 * @see #maxNodeHash()
	 */
	boolean denseNodes();

	/**
	 * @return the maximum hash code value returned by a node in this graph.
	 * This value may be quite large, and is really only useful if <code>denseNodes</code>
	 * returns <code>true</code>
	 * 
	 * @see #denseNodes()
	 */
	int maxNodeHash();
}
