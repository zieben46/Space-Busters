package jig.misc.graph;


/**
 * An edge between two <code>GridCoordinate</code> nodes.
 * 
 * @author Scott Wallace
 *
 * @see GridCoordinate
 * @see Edge
 */
public class GridAdjacency implements Edge<GridCoordinate> {
	private GridCoordinate src, dst;
	private double cost;

	/**
	 * Creates an edge between the source and destination nodes with a 
	 * specified cost.
	 * 
	 * @param s the source node
	 * @param d the destination node
	 * @param c the cost of the edge between them
	 */
	public GridAdjacency(GridCoordinate s, GridCoordinate d, double c) {
		src = s;
		dst = d;
		cost = c;
	}

	/**
	 * {@inheritDoc}
	 */
	public double getCost() {
		return cost;
	}

	/**
	 * {@inheritDoc}
	 */
	public GridCoordinate getDestination() {
		return dst;
	}

	/**
	 * {@inheritDoc}
	 */
	public GridCoordinate getSource() {
		return src;
	}
	
	public String toString() {
		return "[" + src.toString() + " adj to " + dst.toString() + ": " + cost + " ]";
		 
	}
	
}