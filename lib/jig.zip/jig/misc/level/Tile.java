package jig.misc.level;

import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.List;

import jig.engine.ImageResource;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.Viewable;


/**
 * This is an abstract class that you should override to suit your needs for a tile. 
 * 
 * At the very minimum you should set the frames for the tile, override init, and
 * override encode.
 * 
 */
public abstract class Tile<L extends Level<? extends Tile<L>>> implements Viewable {
	
	/** The default height and width of a tile in grid coordinates */
	protected static final int DEFAULT_TILE_EXTENT = 1;
	
	/** The default visible frame for a tile */
	protected static final int DEFAULT_VISIBLE_FRAME = 0;
	
	/** The separator between different class encodings.
	 *  Your encode class should use this to separate your data form super.encode() */
	protected static final String CLASS_SEPARATOR = "`";
				
	protected List<ImageResource> frames;

	protected boolean active = true;

	protected int width, height;
	protected int visibleFrame = DEFAULT_VISIBLE_FRAME;
	
	/**
	 * Constructs a default tile to be used for reflection.
	 */
	public Tile() {};

	/**
	 * Sets this sprite's frameset using the specified 
	 * list of ImageResource objects.
	 * @param frameset
	 *            a list of ImageResource objects which together make
	 *            up all the frames this sprite is capable of displaying.
	 */
	public void setFrameSet(final List<ImageResource> frameset) {
		frames = frameset;
		width = frames.get(0).getWidth();
		height = frames.get(0).getHeight();
	}
	
	/**
	 * Sets this sprite's frameset using the specified resource name
	 * to load an ImageResource from the current factory.
	 * @param rscName
	 *            the name of the ImageResource which will visually represent
	 *            this entity.
	 */
	public void setFrameSet(final String rscName) {
		setFrameSet(ResourceFactory.getFactory().getFrames(rscName));
	}
	
	/**
	 * This method renders the tile with the given image resource and rendering context.
	 * @param rc
	 * @param ir
	 * @param x
	 * @param y
	 */
	public void render(RenderingContext rc, ImageResource ir, double x, double y) {
		if (!active) return;
		
		ir.render(rc, AffineTransform.getTranslateInstance(x, y));
	}

	/**
	 * The method is not supported by tile. Instead the tile should
	 * be rendered at a specific spot using the other versions of render.
	 *
	 */
	public void render(RenderingContext rc) {
		throw new UnsupportedOperationException("Not supported");
	}
	
	/**
	 * Renders this tile at the given location.
	 * 
	 * @param rc
	 * @param x
	 * @param y
	 */
	public void render(RenderingContext rc, double x, double y) {
		render(rc, frames.get(visibleFrame), x, y);
	}
	
	/**
	 * @return the horizontal extent of this Tile in Grid units
	 * @see #getTileCoordinates(Point, java.awt.geom.Point2D.Double)
	 */
	public int getGridWidth() {return DEFAULT_TILE_EXTENT ;}

	/**
	 * @return the vertical extent of this Tile in Grid units
	 * @see #getTileCoordinates(Point, java.awt.geom.Point2D.Double)
	 */
	public int getGridHeight() {return DEFAULT_TILE_EXTENT ;}
	
	/**
	 * This method must be overridden if getGridWidth() or getGridHeight()
	 * returns a value greater than 1.
	 * 
	 * @see #getTileCoordinates(Point, java.awt.geom.Point2D.Double)
	 */
	public Point2D.Double getTileCoordinates(Point2D.Double gridc) {
		Point2D.Double np = (Point2D.Double)gridc.clone();
		
		np.x -= (int)np.x;
		np.y -= (int)np.y;
		return np;
		 
	}
	
	/**
	 * Tiles are active by default, and typically a user will
	 * have little if any reason to set a tiles activation to
	 * anything else. 
	 * 
	 */
	public void setActivation(boolean a) { active = a; }

	/**
	 * @return the tile's activation status (typically true)
	 * @see #setActivation(boolean)
	 */
	public boolean isActive() { return active; }

	/**
	 * Updates the tile attributes based on time.
	 * 
	 * This implementation does nothing.
	 * 
	 * Overriding methods should only run when the tile is active.
	 * @param deltaMs
	 */
	public void update(long deltaMs) {}
	
	/**
	 * This method should return a Tile that represents the data given
	 * 
	 * Note: this is a non static factory method that is the opposite of encode
	 * 
	 * @param data the string of data to be used for initalization
	 */
	public abstract Tile<L> decode(String data);
	
	/**
	 * This method should return a string that has all the information
	 * to recreate this tile.
	 */
	public abstract String encode();
	
	/**
	 * This method should be used to initialize or register any level 
	 * data structures that involve this tile for game use.
	 * 
	 * This method is typically called after the level has been loaded
	 * and is not usually called by the level editor.
	 * 
	 * @param gx the tile x position that this tile exists at
	 * @param gy the tile y position that this tile exists at
	 * @param Level the level that this tile has been placed on
	 */
	abstract public void registerInstance(int gx, int gy, L level);
}

