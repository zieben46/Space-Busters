package jig.misc.level;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;

import jig.engine.FontResource;
import jig.engine.KeyInfo;
import jig.engine.PaintableCanvas;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.PaintableCanvas.JIGSHAPE;
import jig.engine.hli.ImageBackgroundLayer;
import jig.engine.hli.ScrollingScreenGame;
import jig.engine.util.Vector2D;

/**
 * This class is a stub class for a level editor.
 * 
 * You should implement this class with your own extension of Tile and Level.
 * 
 * After implementing each of the abstract methods, 
 * the level editor will be able to place tiles
 * on the level and save and load it to/from a file.
 * 
 * @author James Van Boxtel
 */
@SuppressWarnings("unchecked")
public abstract class LevelEditor<T extends Tile, L extends Level<T>> extends ScrollingScreenGame {

	/** These methods are protected fields so that implementing methods can change the default keys */
	protected static int LEVEL_WIDTH_DECREASE_KEY = KeyEvent.VK_J;
	protected static int LEVEL_WIDTH_INCREASE_KEY = KeyEvent.VK_L;
	protected static int LEVEL_HEIGHT_DECREASE_KEY = KeyEvent.VK_I;
	protected static int LEVEL_HEIGHT_INCREASE_KEY = KeyEvent.VK_K;
	protected static int LOAD_LEVEL_KEY = KeyEvent.VK_F1;
	protected static int NEW_LEVEL_KEY = KeyEvent.VK_F2;
	protected static int SAVE_LEVEL_KEY = KeyEvent.VK_F3;
	protected static int DECREASE_BRUSH_SIZE_KEY = KeyEvent.VK_OPEN_BRACKET;
	protected static int INCREASE_BRUSH_SIZE_KEY = KeyEvent.VK_CLOSE_BRACKET;
	protected static int CAMERA_UP_KEY = KeyEvent.VK_UP;
	protected static int CAMERA_DOWN_KEY = KeyEvent.VK_DOWN;
	protected static int CAMERA_RIGHT_KEY = KeyEvent.VK_RIGHT;
	protected static int CAMERA_LEFT_KEY = KeyEvent.VK_LEFT;
	protected static final int TOGGLE_HELP_SCREEN = KeyEvent.VK_SLASH;
	
    protected static int MAX_BRUSH_SIZE = 20;

    /** Used to select files for loading and saving */
    private JFileChooser fileChooser;
    
    /** The current level loaded */
    protected L currentLevel;
    
    /** The background layer by default is black */
    protected ImageBackgroundLayer backgroundLayer;   

    /** Used to look around the level this is the point to center on */
    protected Vector2D camera = new Vector2D(0,0);
    
    /** Current mouse position */
    protected int mouseX = 0;
    protected int mouseY = 0;
    protected int currentXTile;
    protected int currentYTile;
    
    /** Whether to render help or not */
	private boolean renderHelp = false;
    
    /** A hash of the last paint spot and settings
       to prevent painting in the same spot with the
       same settings over and over again */
    protected int lastPaintHash = -1; 
    
    /** Keep track of if the mouse was last clicked */
    protected boolean mouseClicked = false;    
    
    /** Directory to open file chooser in */
    protected String loadSaveDir = ".";
    
    /** This is the tile that will be put into the level where you click */
    protected T brushTile = null;
    
    /** The width and height the brush should paint onto the map */
    protected int brushSize = 1;
        
    /** A copy of all the KeyInfo that happened since the last update */
    protected ArrayList<KeyInfo> keyList;
    
    /** Various fonts used for rendering */
    protected FontResource smallWhiteFont;
    protected FontResource smallBlackFont;

    /**
     * This creates a level editor with the given width and height in screen coordinates.
     * 
     * @param screenWidth
     * @param screenHeight
     */
    public LevelEditor(int screenWidth, int screenHeight) {
    	super(screenWidth, screenHeight, false);
        gameframe.setTitle("Level Editor");

        //load all the image resources and fonts
        loadResources();
        
        //Create a file chooser
        fileChooser = new JFileChooser(loadSaveDir);
        
        // background layer
        String backgroundRsc = PaintableCanvas.loadStandardFrameResource(100, 100, JIGSHAPE.RECTANGLE, Color.black);
		backgroundLayer = new ImageBackgroundLayer(ResourceFactory.getFactory().getFrames(backgroundRsc).get(2), screenWidth,
				screenHeight, ImageBackgroundLayer.TILE_IMAGE);
        
		// level layer
        currentLevel = loadDefaultLevel();
        gameObjectLayers.add(currentLevel);
        
        int worldWidth = currentLevel.getWidth() * currentLevel.getTileSize();
        int worldHeight = currentLevel.getHeight() * currentLevel.getTileSize();
        setWorldBounds(new Rectangle(0, 0, worldWidth, worldHeight));
        centerCamera();
        
        brushTile = currentLevel.getDefaultTile();
    }

    
    /**
     * This method loads all resources and sets all variables that the level editor needs.
     * 
     * Overriding methods should call this method and should also set all protected fields they need
     * to change.
     */
    protected void loadResources() {
        
        //load all the graphics and sounds\

        smallWhiteFont = ResourceFactory.getFactory().getFontResource(new Font("Sans Serif", Font.BOLD, 14), Color.white, null);
        smallBlackFont = ResourceFactory.getFactory().getFontResource(new Font("Sans Serif", Font.BOLD, 14), Color.black, null);
    }
    

    @Override
    /**
     * This updates the mouse position the current tile being hovered over, and handles keyboard input.
     * Overriding methods may be interested in using the following fields after super.update has been called.
     * mouseX, mouseY, currentXTile, currentYTile, brushTile, brushSize, keyList;
     */
    public void update(final long deltaMs) {

        super.update(deltaMs);
    	
        processMouse();
        processKeyboard();

        centerOnPoint(camera);
        
        if(currentLevel != null)
        	currentLevel.setScreenToWorldTransform(this.getScreenToWorldTransform());
    }

    private int calculatePaintHash()
    {    	
		final int prime = 31;
		int result = 1;
		result = prime * result + brushSize;
		result = prime * result
				+ ((brushTile == null) ? 0 : brushTile.hashCode());
		result = prime * result + currentXTile;
		result = prime * result + currentYTile;
		return result;
	}


	/**
     * This method should process the mouse.
     * 
     * The current implementation records the current mouse location and tile it is under, places the brush tile on all painted
     * tiles (tiles that are within the brushSize of the selected tile)
     * 
     */
	protected void processMouse() {

        //record mouse location
        mouseX = mouse.getLocation().x;
        mouseY = mouse.getLocation().y;
        
        if(currentLevel != null) {
        	Vector2D currentTile = currentLevel.worldToGrid(screenToWorld(new Vector2D(mouseX, mouseY)));
        	currentXTile = (int) currentTile.getX();
        	currentYTile = (int) currentTile.getY();
        }
        
        //mouse click actions
        if(mouse.isLeftButtonPressed()) {
        	        	
            //If the brush state hasn't changed, then lets just stop
            int newPaintHash = calculatePaintHash();
            if(newPaintHash == lastPaintHash)
            {
            	return;
            }
            else
            {
            	lastPaintHash = newPaintHash;
            }
        	
        	//clear out all invalidated tiles
        	//for each tile the new brush is placing on
        	for (int x = currentXTile, w = currentXTile + brushSize * brushTile.getGridWidth(); x<w; ++x) {
                for (int y = currentYTile, h = currentYTile + brushSize * brushTile.getGridHeight(); y<h; ++y) {
                    currentLevel.invalidateTile(x, y, currentLevel.getDefaultTile());
                }
        	}
        	
        	//put new tiles in all locations
        	for (int x = currentXTile, w = currentXTile + brushSize * brushTile.getGridWidth(); x<w; x += brushTile.getGridWidth()) {
                for (int y = currentYTile, h = currentYTile + brushSize * brushTile.getGridHeight(); y<h; y += brushTile.getGridHeight()) {
                	T newTile = (T) brushTile.decode(brushTile.encode());
                	                
                	if(newTile == null)
                		throw new IllegalStateException("Brush did not decode");
                	currentLevel.putTile(newTile, x, y);
                }
            }
        	
        }
    }
    
    /**
     * This method should process the keyboard.
     * 
     * The current implementation processes the following events:
     * load level, load default level, save level, change brush size, move camera,
     * change level size
     * 
     * Overriding methods should access the keyList field to access keyboard info.
     * 
     * The default keys can be changed by changing the protected fields ending in KEY
     * 
     */
    protected void processKeyboard() {        
        KeyInfo k2;
        
        keyList = new ArrayList<KeyInfo>();

		while ((k2 = keyboard.get()) != null) {
			keyList.add(k2);
		}
		
		for(KeyInfo k : keyList)
		{        
			int keyCode = k.getCode();
			
			if(!k.wasPressed())
				continue;
			
			if(keyCode == LOAD_LEVEL_KEY)
			{
                loadLevel();
                refreshWorldBounds();
                centerCamera();
			}
			else if(keyCode == NEW_LEVEL_KEY)
			{
                loadDefaultLevel();
                refreshWorldBounds();
                centerCamera();
			}
			else if(keyCode == SAVE_LEVEL_KEY)
			{
                saveLevel();				
			}
			else if(keyCode == CAMERA_UP_KEY)
			{
                if (camera.getY() > 0) {
                    camera = camera.translate(new Vector2D(0, -currentLevel.getTileSize()));
                }
			}
			else if(keyCode == CAMERA_DOWN_KEY)
			{
                if (camera.getY() < currentLevel.getHeight() * currentLevel.getTileSize()) {
                    camera = camera.translate(new Vector2D(0, +currentLevel.getTileSize()));
                }
			}
			else if(keyCode == CAMERA_LEFT_KEY)
			{
                if (camera.getX() > 0) {
                    camera = camera.translate(new Vector2D(-currentLevel.getTileSize(), 0));
                }
			}
			else if(keyCode == CAMERA_RIGHT_KEY)
			{
                if (camera.getX() < currentLevel.getWidth() * currentLevel.getTileSize()) {
                    camera = camera.translate(new Vector2D(+currentLevel.getTileSize(), 0));
                }
			}
			else if(keyCode == INCREASE_BRUSH_SIZE_KEY)
			{
                if (brushSize < MAX_BRUSH_SIZE) {
                    ++brushSize;
                }
			}
			else if(keyCode == DECREASE_BRUSH_SIZE_KEY)
			{
                if (brushSize > 1) {
                    --brushSize;
                }
			}
			else if(keyCode == LEVEL_WIDTH_DECREASE_KEY)
			{
                if (currentLevel.getWidth() > 1) {
                    currentLevel.resize(currentLevel.getWidth() - 1, currentLevel.getHeight());
                    refreshWorldBounds();
                }
			}
			else if(keyCode == LEVEL_WIDTH_INCREASE_KEY)
			{
				currentLevel.resize(currentLevel.getWidth() + 1, currentLevel.getHeight());
				refreshWorldBounds();
			}
			else if(keyCode == LEVEL_HEIGHT_DECREASE_KEY)
			{
                if (currentLevel.getWidth() > 1) {
                    currentLevel.resize(currentLevel.getWidth(), currentLevel.getHeight() - 1);
                    refreshWorldBounds();
                }
			}
			else if(keyCode == LEVEL_HEIGHT_INCREASE_KEY)
			{
				currentLevel.resize(currentLevel.getWidth(), currentLevel.getHeight() + 1);
				refreshWorldBounds();
			}
			else if(keyCode == TOGGLE_HELP_SCREEN)
			{
				renderHelp = !renderHelp;
			}
		}

    }

    /**
     * This method simply updates the world bounds to the current level size.
     */
    private void refreshWorldBounds()
    {
    	setWorldBounds(0,
    				   0,
    				   currentLevel.getWidth() * currentLevel.getTileSize(),
    				   currentLevel.getHeight() * currentLevel.getTileSize());
    }
    
    /**
     * This method renders the current level.
     * 
     * Overriding methods may be interested in rendering controls and the current tile
     * that the mouse is over (currentXTile, currentYTile)
     */
    public void render(RenderingContext rc) {
    	backgroundLayer.render(rc);
        super.render(rc);
               
        T currentTile = currentLevel.getTile(currentXTile, currentYTile);
        
        if(currentTile != null) {
            //render brush
        	if(brushTile != null)
        	{
                for (int i = 0, w = brushSize * brushTile.getGridWidth(); i<w; i += brushTile.getGridWidth()) {
                    for (int j = 0, h = brushSize * brushTile.getGridHeight(); j<h; j += brushTile.getGridHeight()) {
                        Tile current = currentLevel.getTile(currentXTile + i, currentYTile + j);
                        if (current != null) {
                        	Vector2D paintCoord = worldToScreen(currentLevel.gridToWorld(new Vector2D(currentXTile + i, currentYTile + j)));
                        	brushTile.render(rc,
                        			paintCoord.getX(),
                        			paintCoord.getY());
                        }
                    }
                }
        	}
        }
        
        if(renderHelp)
        {
        	String[] helpString = {"Help",
        		"Change Level Width - " + KeyEvent.getKeyText(LEVEL_WIDTH_DECREASE_KEY) + "," + KeyEvent.getKeyText(LEVEL_WIDTH_INCREASE_KEY),
        		"Change Level Height - " + KeyEvent.getKeyText(LEVEL_HEIGHT_DECREASE_KEY) + "," + KeyEvent.getKeyText(LEVEL_HEIGHT_INCREASE_KEY),
        		"Change Brush Size - " + KeyEvent.getKeyText(DECREASE_BRUSH_SIZE_KEY) + "," + KeyEvent.getKeyText(INCREASE_BRUSH_SIZE_KEY),
        		"Move Camera - " + KeyEvent.getKeyText(CAMERA_UP_KEY) + "," + KeyEvent.getKeyText(CAMERA_DOWN_KEY) + "," + KeyEvent.getKeyText(CAMERA_LEFT_KEY) + "," + KeyEvent.getKeyText(CAMERA_RIGHT_KEY),
        		"Load Level - " + KeyEvent.getKeyText(LOAD_LEVEL_KEY),
        		"New Level - " + KeyEvent.getKeyText(NEW_LEVEL_KEY),
        		"Save Level - " + KeyEvent.getKeyText(SAVE_LEVEL_KEY),
        		};
        	
        	
        	int x = smallWhiteFont.getStringWidth("  ");
        	int y = smallWhiteFont.getStringWidth("  ");
        	for(int i=0; i<helpString.length; ++i)
        	{
            	smallWhiteFont.render(helpString[i], rc,
            			AffineTransform.getTranslateInstance(
            					x,
            					y));
            	y += 1.1 * smallWhiteFont.getHeight();
        	}

        }
        else
        {
        	String helpString = "Press ? For Help";
        	smallWhiteFont.render(helpString, rc,
        			AffineTransform.getTranslateInstance(
        					smallWhiteFont.getStringWidth("  "),
        					gameframe.getHeight() - smallWhiteFont.getHeight() - smallWhiteFont.getStringWidth("  ")));
        }
    }
    
    /**
     * This method should load a default level.
     * 
     * Typically this is a blank slate level that should come up by
     * default in the level editor.
     * 
     */
    abstract public L loadDefaultLevel();
    
    /**
     * This method loads a level from a filename
     * @param filename
     * @return
     */
    abstract public L loadLevel(String filename);
    
    /**
     * This method brings up a file chooser and then loads the selected file.
     */
    private void loadLevel() {

        int returnVal = fileChooser.showOpenDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            String filename = file.getAbsolutePath();

            if(currentLevel != null)
        	{
        		gameObjectLayers.remove(currentLevel);
        	} 	
        	
        	currentLevel = loadLevel(filename);
        	
        	gameObjectLayers.add(currentLevel);
        }
       
    }

    /**
     * This method brings up a file chooser and then saves to the selected file.
     */
    public void saveLevel() {


        int returnVal = fileChooser.showSaveDialog(null);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            String filename = file.getAbsolutePath();

            currentLevel.saveLevel(filename);
        } 

    }

    /**
     * This method simply centers the camera on the level.
     */
    private void centerCamera()
    {
    	camera = new Vector2D(
    				(currentLevel.getWidth()/2) * currentLevel.getTileSize(),
    				(currentLevel.getHeight()/2) * currentLevel.getTileSize()
    				);
    }
}
