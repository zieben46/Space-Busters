package jig.misc.level;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.Map.Entry;

import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.ViewableLayer;
import jig.engine.util.Vector2D;
import jig.misc.graph.Edge;
import jig.misc.graph.Grid;
import jig.misc.graph.GridAdjacency;
import jig.misc.graph.GridCoordinate;

/**
 * The playing field encapsulates the dynamic area of the screen for this game.
 * 
 * You should extend this class to use your specific type of tiles and add any other information
 * you want to have on a playing field. 
 * 
 * Usually the playing field can be thought of as one 'room' in a large level, but you may only have one
 * 'room' in your game. The jig.engine.hli.level.Level class is a stub for you to use to link all your PlayingFields
 * together.
 *   
 * @author Scott Wallace
 * @author James Van Boxtel
 * 
 */
@SuppressWarnings("unchecked")
public abstract class Level<T extends Tile> extends Grid implements ViewableLayer {

	
	/**
	 * A tile is put into each cell that it occupies in the cell map.
	 * Thus if a single tile spans tiles [0][0] and [0][1], it can be
	 * looked up by accessing either cell.
	 */
	private T[][] cellmap;
	
	/**
	 * A tile is put into only one cell (the cell corresponding to its upper
	 * left corner) in the rendermap.  Thus, all cells in the rendermap
	 * can be drawn at the coordinates they appear at in this map. No tile
	 * will be drawn more than necessary.
	 */
	private T[][] rendermap;
	
	private boolean active = true;
	
	protected int tileSize;
	
    /** The default tile to fill in invalidated spots in the map */
    protected T defaultTile = null;
		
	private final AffineTransform worldToScreenTransform = new AffineTransform();
	private AffineTransform screenToWorldTransform = new AffineTransform();
	
	/**
	 * Creates a default level with the given data.
	 * @param defaultTileWidth default level width in tiles
	 * @param defaultTileHeight default level height in tiles
	 * @param tilePixelSize size in pixels of a 1x1 tile
	 * @param xPixelOffset x offset in pixels the level should be rendered at
	 * @param yPixelOffset y offset in pixels the level should be rendered at
	 * @param defaultTile the default tile that should fill in the level
	 */
	public Level(int defaultTileWidth, int defaultTileHeight, int tilePixelSize,
			T defaultTile) {
		
		cellmap = (T[][]) new Tile[defaultTileWidth][defaultTileHeight];
		rendermap = (T[][]) new Tile[defaultTileWidth][defaultTileHeight];
		active = true;
		gWidth = defaultTileWidth;
		gHeight = defaultTileHeight;
		tileSize = tilePixelSize;
		
		setDefaultTile(defaultTile);
		
		//Put default tiles in all the coordinates
        for (int y = 0; y < gHeight; ++y) {
            for (int x = 0; x < gWidth; ++x) {
                putTile(defaultTile, x, y);
            }
        }
		
		setGridToWorldTransform(new AffineTransform(
										tileSize, 0.0, 
										0.0, tileSize, 
										0, 0));
		
		setWorldToScreenTransform(AffineTransform.getTranslateInstance(0, 0));
	}
	
	/**
	 * Creates a level with the given data and filename.
	 * 
	 * The file should be structured as follows (the default unless you change it):
	 * 
	 * The first two lines should be a integer width and height respectively.
	 * 
	 * Then there should be a line for each tile going in row major order. This means that if you
	 * have a 10x10 playing field, the first ten strings will decode to the tiles on the top row.
	 *
	 *
	 * @param defaultTileWidth default level width in tiles
	 * @param defaultTileHeight default level height in tiles
	 * @param tilePixelSize size in pixels of a 1x1 tile
	 * @param xPixelOffset x offset in pixels the level should be rendered at
	 * @param yPixelOffset y offset in pixels the level should be rendered at
	 * @param defaultTile the default tile that should fill in the level
	 */
	public Level(int tileWidth, int tileHeight, int tilePixelSize,
			T defaultTile, String fileName)
	{
		this(tileWidth, tileHeight, tilePixelSize,
				defaultTile);
		
		loadLevel(fileName);
	}
	

	/**
	 * Resizes the level to fit to the given width and height.
	 * 
	 * Large tiles can be invalidated and new tiles can be added in the process
	 * If this happens, they are filled in with the tile given.
	 * 
	 * @param width width in tiles the new level size should be
	 * @param height height in tiles the new level size should be
	 */
	public void resize(int width, int height)
	{
		//make new copy
		T[][] newcellmap = (T[][]) new Tile[width][height];
		T[][] newrendermap = (T[][]) new Tile[width][height];
		
		//invalidate right side if smaller
        for (int x = width; x < gWidth; ++x) {
            for (int y = 0; y < gHeight; ++y) {
            	invalidateTile(x, y, defaultTile);
            }
        }
        
        //invalidate bottom tiles if smaller
        for (int x = 0; x < gWidth; ++x) {
        	for (int y = height; y < gHeight; ++y) {
        		invalidateTile(x, y, defaultTile);
            }
        }
		
        //copy old tiles to new tiles
		int minWidth = Math.min(width, gWidth);
		int minHeight = Math.min(height, gHeight);
		for (int x = 0; x < minWidth; x++) {
			for (int y = 0; y < minHeight; y++) {
				if (cellmap[x][y] != null) {
					newcellmap[x][y] = cellmap[x][y];
				}
				
				if (rendermap[x][y] != null) {
					newrendermap[x][y] = rendermap[x][y];									
				}
			}
		}
		
        //put default tiles on right side if bigger
        for (int x = gWidth; x < width; ++x) {
            for (int y = 0; y < height; ++y) {
				newcellmap[x][y] = defaultTile;
            	newrendermap[x][y] = defaultTile;
            }
        }
        
        //put default tiles on bottom if bigger
        for (int x = 0; x < width; ++x) {
        	for (int y = gHeight; y < height; ++y) {
        		newcellmap[x][y] = defaultTile;
        		newrendermap[x][y] = defaultTile;
            }
        }
		
		cellmap = newcellmap;
		rendermap = newrendermap;
		gWidth = width;
		gHeight = height;
	}
	
	/**
	 * This loads a level from the given filename.
	 * @param filename
	 * 			The filename to load
	 */
	private void loadLevel(String filename)
    {
		//System.out.println("loading level");
		
		//load the level in as a list of strings
		List<String> levelStringList = getFileContents(filename);

		//resize the map to the correct size
		resize(Integer.parseInt(levelStringList.get(0)),
						Integer.parseInt(levelStringList.get(1)));
		
		int compressNumber;
		int headerOffset;
		try {
			compressNumber = Integer.parseInt(levelStringList.get(2));
			headerOffset = 3;
		} catch (NumberFormatException e) {
			compressNumber = 0;
			headerOffset = 2;
		}
		
		//Compression used
		if(compressNumber > 0)
		{
	    	HashMap<Character, String> dictionary = new HashMap<Character, String>();
	    	
			for(int i=0; i<compressNumber; ++i)
			{
				String line = levelStringList.get(headerOffset + i);
				String[] array = line.split(":");
				dictionary.put(array[1].charAt(0), array[0]);
			}
			
	        for (int y = 0; y < gHeight; ++y) {
                int offset = y + headerOffset + compressNumber;
                
                if (levelStringList.size() <= offset) {
                	System.err.println("ERROR: Playingfield load failed, # of lines is too small");
                    return;
                }

                String currentLine = levelStringList.get(offset);

	            for (int x = 0; x < gWidth; ++x) {
	            	
	            	char key = currentLine.charAt(x);
	                
	                if(!dictionary.containsKey(key))
	                {
	                	System.err.println("ERROR: Playingfield load failed char " + x + " not in dictionary");
	                	return;
	                }
	                
	                String value = dictionary.get(key);
	                
	                loadTile(x, y, value);
	            }
	        }
		}
		else //compression not used
		{
			
	        //load each tile from the file
	        for (int y = 0; y < gHeight; ++y) {
	            for (int x = 0; x < gWidth; ++x) {
	                int offset = (y * gWidth) + x + headerOffset;
	                
	                if (levelStringList.size() <= offset) {
	                	System.err.println("ERROR: Playingfield load failed, # of lines is too small");
	                    return;
	                }
	                
	                String currentLine = levelStringList.get(offset);
	                if(currentLine.equals("null")) //no tile in this spot (previous tile extent > 1)
	                	continue;
	                
	                loadTile(x, y, currentLine);
	            }
	        }
		}

        //System.out.println("Level loaded. Tile at 0,0 is " + cellmap[0][0].toString());
	}
    
	private void loadTile(int x, int y, String tileString)
    {

		// TODO: James verify this.
		if (tileString.equals("null")) {
			return;
		}
        String[] currentArgs = tileString.split(Tile.CLASS_SEPARATOR);
        Stack<String> stringStack = new Stack<String>();
        stringStack.addAll(Arrays.asList(currentArgs));
        
        String className = stringStack.pop();
        if(className.length() == 1)
        	className = stringStack.pop(); //ignore singleton in level data
        String tileData = stringStack.pop();
                 
        Class<? extends T> newClass;
		try {
			newClass = (Class<? extends T>) Class.forName(className);
			// TODO: can be optimized by storing all these in a dictionary so
			// newInstance is only called once per type, not once per instance
            T tile = newClass.newInstance();
            tile = (T) tile.decode(tileData);
            putTile(tile, x, y);
		} catch (ClassNotFoundException e) {
			System.err.println("While building Tile: " + className);
			e.printStackTrace();
		} catch (InstantiationException e) {
			System.err.println("While building Tile: " + className);
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.err.println("While building Tile: " + className);
			e.printStackTrace();
		}
    }
	
	/**
	 * This method returns the level encoded as a string.
	 * 
	 * This implementation stores the width on the first line, the height on the second line,
	 * and each tile encoded as a string in row major order on the rest of the lines.
	 * 
	 * @return 
	 */
    public boolean saveLevel(String filename) {

        boolean compressed = true;
        
    	//chars that will be used to compress tiles using a dictionary
    	Stack<Character> dictionaryChars = new Stack<Character>();
    	for(char letter='!'; letter<='+'; letter++) dictionaryChars.add(letter);
    	for(char letter='a'; letter<='z'; letter++) dictionaryChars.add(letter);
    	for(char letter='0'; letter<='9'; letter++) dictionaryChars.add(letter);
    	for(char letter='A'; letter<='Z'; letter++) dictionaryChars.add(letter);
    	
    	//dictionary mapping tile encodings to characters
    	HashMap<String, Character> dictionary = new HashMap<String, Character>();
 
        String header = getWidth() + System.getProperty("line.separator");
        header += getHeight() + System.getProperty("line.separator");

        String compressedContents = "";
        String uncompressedContents = "";
        
        //create the compressed format
        compression:
        for (int y = 0; y < getHeight(); ++y) {
            for (int x = 0; x < getWidth(); ++x) {
            	Tile<?> t = getRendered(x, y);

            	String tileLine = "";
            	if(t == null) tileLine = "null";
            	else tileLine = t.encode() + Tile.CLASS_SEPARATOR + t.getClass().getName();
            	
            	if(!dictionary.containsKey(tileLine))
            	{
            		if(dictionaryChars.size() > 0)
            		{
            			dictionary.put(tileLine, dictionaryChars.pop());
            		}
            		else
            		{
            			compressed = false;
            			break compression;
            		}
            	}
            	
            	compressedContents += dictionary.get(tileLine);
            	
            	uncompressedContents += tileLine + System.getProperty("line.separator");
            }
            compressedContents += System.getProperty("line.separator");
        }
        
        if(compressed)
        {
	        String dictionaryContents = dictionary.size() + System.getProperty("line.separator");
	        for(Entry<String,Character> e : dictionary.entrySet())
	        {
	        	dictionaryContents += e.getKey() + ":" + e.getValue() + System.getProperty("line.separator");
	        }
	
	        return writeFile(header + dictionaryContents + compressedContents, filename);
        }
        else
        {	
	        return writeFile(header + uncompressedContents, filename);
        }
    }
    
    /**
     * This method calls the registerInstance method on every
     * tile that exists in the level
     */
    public void registerAllTiles()
    {
        for (int x = 0; x < gWidth; ++x) {
            for (int y = 0; y < gHeight; ++y) {
				T tile = getRendered(x, y);
				if(tile != null)
            		tile.registerInstance(x, y, this);
            }
        }
    }
		    
	/**
	 * This method is intended to only be used by subclasses to put tiles into the
	 * tile map. If the tile will not fit, nothing is done.
	 * 
	 * @param t
	 * 			the tile to be put in the tile map
	 * @param gx
	 * 			the grid x location
	 * @param gy
	 * 			the grid y location
	 */
	protected void putTile(T t, int gx, int gy) {
		if (gx < 0 || gy < 0 ||
				gx+t.getGridWidth() > gWidth ||
				gy+t.getGridHeight() > gHeight) {
			//System.err.println("WARNING: Requested tile outside of boundary " + gx + ":" + gy);
			return;
		}
		int ex = t.getGridWidth();
		int ey = t.getGridHeight();
		for (int x = 0; x < ex; x++ ) {
			for (int y = 0; y < ey; y++) {
				cellmap[gx+x][gy+y] = t;
				rendermap[gx+x][gy+y] = null;
			}
		}
		rendermap[gx][gy] = t;
	}

	/**
	 * Gets a tile from the given grid coordinates.
	 * 
	 * If no such tile exists, null is returned.
	 * 
	 * @param gx x coordinate
	 * @param gy y coordinate
	 * @return the tile or null if no tile exists at this point
	 */
	public T getTile(int gx, int gy) {
		if (gx < 0 || gy < 0 || gx >= gWidth || gy >= gHeight) {
			//System.err.println("WARNING: Requested tile outside of boundary " + gx + ":" + gy);
			return null;
		}
		return cellmap[gx][gy];
	}

	/**
	 * Gets a render tile from the given grid coordinates.
	 * 
	 * If no such tile exists, null is returned.
	 * 
	 * @param gx x coordinate
	 * @param gy y coordinate
	 * @return the tile or null if no tile exists at this point
	 */
	public T getRendered(int gx, int gy) {
		if (gx < 0 || gy < 0 || gx >= gWidth || gy >= gHeight) {
			//System.err.println("WARNING: Requested tile outside of boundary " + gx + ":" + gy);
			return null;
		}
		return rendermap[gx][gy];
	}
	
	/**
	 * Finds the tile associated with the current position and fills its area in
	 * with the given default tile. This is mainly used to remove other large tiles
	 * before you put a new tile in this spot.
	 * 
	 * @param x
	 * @param y
	 * @param defaultTile
	 */
	public void invalidateTile(int x, int y, T defaultTile)
	{
		T tile = getTile(x,y);
    	if(tile == null) return;
    	
    	int width = tile.getGridWidth();
    	int height = tile.getGridHeight();
    	
    	T search = null;
    	int fx=-1,fy=-1;
    	
	   	//search for the actual render tower by searching through
		//each tile to the top and left of it
		for(int gx = x-width+1; gx<=x; ++gx) {
			for (int gy = y-height+1; gy<=y; ++gy) {
				T newsearch = getRendered(gx, gy);
				
					//System.out.println("Render Tile @ [" + gx + ":" + gy + "]" + newsearch + "..." + currentLevel.tilemap.getTile(gx, gy));
		                			
				if(newsearch == tile)
				{
					//System.out.println("found tile [" + gx + ":" + gy + "]" + newsearch);
					if(search != null)
					{
						throw new IllegalStateException("Rendering of two different tiles overlap");
					}
					search = newsearch;
					fx = gx;
					fy = gy;
				}
			}
		}
		
		//replace all search tiles area with default tile
		for (int nx = fx, nw = fx + search.getGridWidth(); nx<nw; ++nx) {
	        for (int ny = fy, nh = fy + search.getGridHeight(); ny<nh; ++ny) {
	        	putTile(defaultTile, nx, ny);                        	
	        }
		}
	}
	
	
	/**
	 * This method should render all the playing field objects
	 * if the playing field is active.
	 * 
	 * This implementation simply renders the tile map.
	 */
	public void render(RenderingContext rc) {
		
		if (!active) return;
		
		AffineTransform tr = rc.getTransform();
		rc.setTransform(worldToScreenTransform);
		
		for (int x = 0; x < gWidth; x++) {
			for (int y = 0; y < gHeight; y++) {
				if (rendermap[x][y] != null) {
					Vector2D renderPosition = gridToWorld(new Vector2D(x, y));
					rendermap[x][y].render(rc, 
							renderPosition.getX(),
							renderPosition.getY());					
				}
			}
		}
		
		rc.setTransform(tr);			

	}
	

	/**
	 * This method should update all internal objects of the playing field
	 * if the playing field is active.
	 * 
	 * This implementation does nothing.
	 */
	public void update(long ms) {
		if (!active) return;
		for (int x = 0; x < gWidth; x++) {
			for (int y = 0; y < gHeight; y++) {
				if (rendermap[x][y] != null) {
					rendermap[x][y].update(ms);					
				}
			}
		}
	}
	
	/**
	 * Sets the transform between screen coordinates and world coordinates and 
	 * vice versa.
	 * 
	 * @param an invertable affine transform
	 */
	public void setWorldToScreenTransform(AffineTransform at) {
			try {
				AffineTransform bt = at.createInverse();
				worldToScreenTransform.setTransform(at);
				screenToWorldTransform.setTransform(bt);				
			} catch (NoninvertibleTransformException e) {
				ResourceFactory.getJIGLogger().warning("Cannot invert matrix");
			}
	}
	
	/**
	 * Sets the transform between screen coordinates and world coordinates and 
	 * vice versa.
	 * 
	 * @param an invertable affine transform
	 */
	public void setScreenToWorldTransform(AffineTransform at) {
			try {
				AffineTransform bt = at.createInverse();
				screenToWorldTransform.setTransform(at);	
				worldToScreenTransform.setTransform(bt);			
			} catch (NoninvertibleTransformException e) {
				ResourceFactory.getJIGLogger().warning("Cannot invert matrix");
			}
	}
	
	public AffineTransform getScreenToWorldTransform()
	{
		return screenToWorldTransform;
	}
	
	public AffineTransform getWorldToScreenTransform()
	{
		return worldToScreenTransform;
	}
	
	/**
	 * Computes a world coordinate from a screen coordinate.
	 * @param s the screen coordinates passed in as a Vector2D
	 * @return the world coordinate as a Vector2D
	 */
	public Vector2D screenToWorld(Vector2D s)
	{
		Point2D p = new Point2D.Double(s.getX(), s.getY());
		screenToWorldTransform.transform(p,p);
		return new Vector2D(p.getX(), p.getY());
	}
	
	/**
	 * Computes a screen coordinate from a world coordinate.
	 * @param s the world coordinates passed in as a Vector2D
	 * @return the screen coordinate as a Vector2D
	 */
	public Vector2D worldToScreen(Vector2D w)
	{
		Point2D p = new Point2D.Double(w.getX(), w.getY());
		worldToScreenTransform.transform(p,p);
		return new Vector2D(p.getX(), p.getY());
	}
	
	/**
	 * Gets a tile from the given world coordinates.
	 * 
	 * @param location the world coordinates
	 * @return the tile or null if no tile exists at this point
	 */
	public Tile getTileFromWorldLocation(Vector2D location) {
		Vector2D tileCoord = worldToGrid(location);
		return getTile((int)tileCoord.getX(), (int)tileCoord.getY());
	}

	
	/**
	 * The current implementation assumes straight edges cost 1 and diagonal
	 * edges cost 1.4285
	 */
	@Override
	public List<Edge<GridCoordinate>> getEdges(GridCoordinate gc) { 
		LinkedList<Edge<GridCoordinate>> edges = new LinkedList<Edge<GridCoordinate>>();
		
		int x = gc.getGridX();
		int y = gc.getGridY();
		boolean leftok, rightok, upok, downok;
		leftok = rightok = downok = upok = false;
		double cost;
		
		double defaultCost = 1;
		
		if (x > 0) {
			cost = defaultCost;
			edges.add(new GridAdjacency(gc, getNode(x-1,y), cost));
			leftok = true;
		}
		if (x < gWidth-1) {
			cost = defaultCost;
			edges.add(new GridAdjacency(gc, getNode(x+1,y), cost));
			rightok = true;
		}
		if (y > 0) {
			cost = defaultCost;
			edges.add(new GridAdjacency(gc, getNode(x,y-1), cost));
			upok = true;
		}
		if (y < gHeight-1) {
			cost = defaultCost;
			edges.add(new GridAdjacency(gc, getNode(x,y+1), cost));
			downok = true;
		}
		
		if (upok && rightok) {
			cost = defaultCost * 1.4285;
			edges.add(new GridAdjacency(gc, getNode(x+1,y-1), cost));
		} if (upok && leftok) {
			cost = defaultCost * 1.4285;
			edges.add(new GridAdjacency(gc, getNode(x-1,y-1), cost));
		} if (downok && leftok) {
			cost = defaultCost * 1.4285;
			edges.add(new GridAdjacency(gc, getNode(x-1,y+1), cost));
		} if (downok && rightok) {
			cost = defaultCost * 1.4285;
			edges.add(new GridAdjacency(gc, getNode(x+1,y+1), cost));
		}
		return edges;
	}
	/*
		LinkedList<Edge<GridCoordinate>> edges = new LinkedList<Edge<GridCoordinate>>();
		
		int x = gc.getGridX();
		int y = gc.getGridY();
		boolean leftok, rightok, upok, downok;
		leftok = rightok = downok = upok = false;
		double cost;
		
		if (x > 0 && cellmap[x-1][y].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x-1][y].travelCost)/2;
			
			edges.add(new GridAdjacency(gc, getNode(x-1,y), cost));
			leftok = true;
		}
		if (x < gWidth-1 && cellmap[x+1][y].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x+1][y].travelCost)/2;

			edges.add(new GridAdjacency(gc, getNode(x+1,y), cost));
			rightok = true;
		}
		if (y > 0 && cellmap[x][y-1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x][y-1].travelCost)/2;
			edges.add(new GridAdjacency(gc, getNode(x,y-1), cost));
			upok = true;
		}
		if (y < gHeight-1 && cellmap[x][y+1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x][y+1].travelCost)/2;
			edges.add(new GridAdjacency(gc, getNode(x,y+1), cost));
			downok = true;
		}
		
		if (upok && rightok && cellmap[x+1][y-1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x+1][y-1].travelCost)/1.4;
			edges.add(new GridAdjacency(gc, getNode(x+1,y-1), cost));
		} if (upok && leftok && cellmap[x-1][y-1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x-1][y-1].travelCost)/1.4;
			edges.add(new GridAdjacency(gc, getNode(x-1,y-1), cost));
		} if (downok && leftok && cellmap[x-1][y+1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x-1][y+1].travelCost)/1.4;
			edges.add(new GridAdjacency(gc, getNode(x-1,y+1), cost));
		} if (downok && rightok && cellmap[x+1][y+1].isTraversable()) {
			cost = (cellmap[x][y].travelCost + cellmap[x+1][y+1].travelCost)/1.4;
			edges.add(new GridAdjacency(gc, getNode(x+1,y+1), cost));
		}
		return edges;
	}

    /**
     * Returns the width of the playing field in tiles.
     * 
     * @return width of the playing field in tiles
     */
	public int getWidth() { return gWidth; }
	
    /**
     * Returns the height of the playing field in tiles.
     * 
     * @return height of the playing field in tiles
     */
	public int getHeight() { return gHeight; }
	
    /**
     * Returns the tile map as a grid.
     * 
     * @return the tile map as a grid
     */
	public Grid getGrid() { return this; }
	
	/**
	 * Returns the tile map as a ViewableLayer.
	 * 
	 * We up cast purposely to hide TileMap properties from the user. Methods
	 * that one may want to call on the TileMap, should be called using the
	 * PlayingField
	 * 
	 * @return a ViewableLayer view of the tileLayer
	 */
	public ViewableLayer getTileLayer() {
		return this;
	}
	
	/**
	 * This method returns whether the playing field is active or not.
	 * 
	 * @return if the playing field is active or not
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * This method sets the activation to the given value
	 * 
	 * @param a the value to set the activation
	 */
	public void setActivation(boolean a) {
		active = a;	
	}
	
	/**
	 * This method returns the size of 1 tile in pixels.
	 * @return the size of 1 tile in pixels.
	 */
	public int getTileSize()
	{
		return tileSize;
	}
	
    private final void setDefaultTile(T defaultTile)
    {
        this.defaultTile = defaultTile;
        if(defaultTile.getGridHeight() != 1 || defaultTile.getGridWidth() != 1)
        {
        	throw new IllegalArgumentException("The default brush tile must be 1x1");
        }
    }
    
    public T getDefaultTile()
    {
    	return defaultTile;
    }
    
	static private List<String> getFileContents(String filename)
	{
		// TODO: replace with ResourceFactory.findResource()?
		//URL url = ResourceFactory.getFactory().findResource(filename);
        URL url = ClassLoader.getSystemResource(filename);
        if (url == null) {
        	File test = new File(filename);
        	try {
				url = test.toURI().toURL();
			} catch (MalformedURLException e) {
	        	System.out.println("Level not found... " + filename);
	            throw new Error();
			}
        }
        
        return getContents(url);
	}
    
    
    static private ArrayList<String> getContents(URL url) {
    	
    	ArrayList<String> stringList = new ArrayList<String>();
        
        try {
            InputStream in=url.openStream();
            BufferedReader dis =
                    new BufferedReader(new InputStreamReader(in));
            
            String line = null;
            while ( (line = dis.readLine()) != null) {
            	stringList.add(line);
            }
            
            in.close();
            
            return stringList;
        } catch (IOException e) {
            System.out.println("IO Exception = "+e);
            return null;
        }
    }
    

    static private boolean writeFile(String contents, String filename) {
        try {
            FileWriter fw = new FileWriter(new File(filename));
            fw.write(contents);
            fw.flush();
            fw.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
	
}