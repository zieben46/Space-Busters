package jig.misc.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import jig.engine.ResourceFactory;
import jig.engine.Version;
import jig.engine.j2d.J2DResourceFactory;
import jig.engine.lwjgl.LWResourceFactory;

public class ConfigurationManager {

	/** Java Property for enabling the openGL pipeline */
	public static final String OPEN_GL_PROPERTY = "sun.java2d.opengl";
	
	/** Property used by the JIG configuration to turn on LWJGL */
	public static final String LWJGL_PROPERTY = "jig.lwjgl";
	
	/** Property used by the JIG configuration to turn on fullscreen mode */
	public static final String FULLSCREEN_PROPERTY = "jig.fullscreen";
	
	/** Filename of the JIG custom configuration file */
	public static String jigConfigFileName = "lib/jigconfig.txt";
	
	/** Field that holds the current games configuration properties */
	private static Properties currentConfigProperties;
	

	static {
		ResourceFactory.getJIGLogger().info("Java Version is: " + Version.getJavaVersion().toString() );
		if(Version.getJavaVersion().is(1, 6, 1))
			ResourceFactory.getJIGLogger().warning("This version of Java is known to have a bug with parsing XML files. Please update your version of Java.");
		if(!Version.getJavaVersion().atLeast(1, 6, 0))
			ResourceFactory.getJIGLogger().warning("You have a older version of Java. Newer versions provide significant speed improvements. Please update your version of Java.");

		/* Load the JIG config settings */
		Properties properties = getCurrentProperties();
		
		System.setProperty(OPEN_GL_PROPERTY,
				properties.getProperty(OPEN_GL_PROPERTY));
		
		if (ResourceFactory.getFactory() == null) {
			if(((String)properties.get(LWJGL_PROPERTY))
					.toLowerCase().equals("true"))
			{
				LWResourceFactory.makeCurrentResourceFactory();	
			}
			else
			{
				J2DResourceFactory.makeCurrentResourceFactory();
			}
		}
		
	}
	
	/**
	 * This method should be called to initialize JIG including setting
	 * the selected ResourceFactory from the configuration files.
	 */
	public static void initalize()
	{
		//just ensures the static block is called.
	}
	
	public static Properties loadDefaultProperties()
	{
		/* Load Default Properties */
		ResourceFactory.getJIGLogger().info("Loaded Default Game Properties");
		currentConfigProperties = new Properties();
		currentConfigProperties.setProperty(OPEN_GL_PROPERTY, "false");
		currentConfigProperties.setProperty(LWJGL_PROPERTY, "false");
		
		return currentConfigProperties;
	}
	
	private static FileInputStream openFile(String fileName)
	{
		FileInputStream in = null;
		try {
			//try the current directory
			in = new FileInputStream(jigConfigFileName);
		} catch (FileNotFoundException e) {
			
		}
		return in;
	}
		
	public static Properties loadGameProperties()
	{		
		loadDefaultProperties();
		
		FileInputStream in = openFile(jigConfigFileName);
		//Note: a custom game configuration is not required
		if(in != null)
		{
			try {
				currentConfigProperties.load(in);
				in.close();
				ResourceFactory.getJIGLogger().info("Loaded Custom Game Properties");
			}
			catch (IOException e) {
					//but we should probably know if this happens
					e.printStackTrace();
			}	
		}
		
		return currentConfigProperties;
	}
	
	public static void saveGameProperties(Properties properties)
	{		
		try {
			properties.store(new FileOutputStream(jigConfigFileName), "--JIG Configuration File--");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Properties getCurrentProperties() 
	{
		if(currentConfigProperties == null)
			currentConfigProperties = loadGameProperties();
		return currentConfigProperties;
	}
}
