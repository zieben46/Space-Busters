package jig.misc.config;

import java.awt.Color;
import java.awt.Font;
import java.awt.geom.AffineTransform;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeSet;

import jig.engine.FontResource;
import jig.engine.GameClock;
import jig.engine.GameFrame;
import jig.engine.ImageResource;
import jig.engine.PaintableCanvas;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;
import jig.engine.Sprite;
import jig.engine.PaintableCanvas.JIGSHAPE;
import jig.engine.hli.ImageBackgroundLayer;
import jig.engine.util.Vector2D;

/**
 * TODO: DrawingBenchmark dies in eclipse. because it can't find file
 * TODO: Fix FPS time format for min and max
 * 
 * DrawingBenchmark
 * 
 * This benchmarks the rendering time of a "scene". A scene is comprised of x
 * number of sprites, and y number of background images (centered, tiled, or
 * scaled). Additionally, the sprites (all of them) will either be rotated
 * before each rendering or not. Lastly, the frame width/height can be changed.
 * Therefore, all the benchmark parameters that affect the rendering speed are
 * the following (along with the associated field that must be changed to modify
 * the benchmark settings):
 * 
 *  1) # of sprites - NUM_SPRITES
 *  2) # of background images (and how they are rendered -
 *     centered, tiled, scaled) - NUM_BKGRD_IMAGES and BKGRD_DRAW_MODE
 *  3) rotation of all sprites - this is automatically set on/off for all runs
 *  4) frame size (resolution) - FRAME_WIDTH and FRAME_HEIGHT
 *  
 * All the parameters are changed automatically throughout the execution of the
 * benchmark except for the resolution (frame size). If you want to change the
 * number of sprites or background images rendered, then modify the NUM_SPRITES
 * and NUM_BKGRD_IMAGES arrays.
 * 
 * Lastly, changing BKGRD_DRAW_MODE will probably have an effect on speed.
 * Scaling the background image(s) seems to be the slowest out of the three
 * options (center, tile, scale) in ImageBackgroundLayer.
 * 
 * The unit of time used in the report can easily be switched from sec to
 * ms. Change TIME_FORMAT to do so. 
 * 
 * Change RUNS_PER_CONFIG to change the number of times each unique scene 
 * configuration will be rendered to get the avg, min, and max rendering
 * times.
 * 
 * @author Christian Holton
 * @author James Van Boxtel
 * 
 */
public class DrawingBenchmark {
	
	/** Filename of the JIG benchmark log */
	public static String jigBenchmarkFileName = "lib/jigbenchmark.txt";
	public static String STANDARD_LOG = "STANDARD";
	public static String OPEN_GL_LOG = "OPENGL";
	public static String LWJGL_LOG = "LWJGL";

	public static final int FRAME_WIDTH = 800;

	public static final int FRAME_HEIGHT = 600;

	/** How the background image(s) will be rendered. */
	private static final int BKGRD_DRAW_MODE = ImageBackgroundLayer.TILE_IMAGE;

	/** display output in microseconds */
	public static final int MS = 1;

	/** display output in seconds */
	public static final int SEC = 2;

	/** display output in FPS */
	public static final int FPS = 3;
	
	/** display output in ms or sec */
	public static int TIME_FORMAT = FPS;

	/** the number of sprites to render */
	private static final int NUM_SPRITES = 300;
	
	private static final boolean USE_BACKGROUND = true;
	
	private static final boolean ROTATE = true;

	/**
	 * The number of times a run will be repeated for getting the min, max, and
	 * avg rendering values.
	 */
	private static final int RUNS_PER_CONFIG = 250;

	/** Output all the system info available to Java before the report */
	public static final boolean DISPLAY_SYSTEM_INFO = false;

	private GameFrame frame;
	
	boolean rotate;
	
	boolean useBackground;

	boolean firstFormat = true;

	public static final String SPRITE_SHEET = "jig/resources/shapes.png";
	public static final String SPRITE_SHEET_XML = "jig/resources/shapes.xml";
	public static final String SHAPE_RSC = SPRITE_SHEET + "#shapes";

	private static ImageResource bkgrdImage;

	private ArrayList<ImageBackgroundLayer> backgrounds = new ArrayList<ImageBackgroundLayer>();
	
	private FontResource statusText;

	public static void main(String[] args) {
		//System.setProperty("sun.java2d.d3d", "True");
		run();
	}
	
	public static void run()
	{
		DrawingBenchmark benchmk = new DrawingBenchmark();
		benchmk.initialize();
		benchmk.experiment1();
		System.exit(0);
	}

	private void initialize() {
		
		frame = ResourceFactory.getFactory().getGameFrame(
				"JIG Drawing Benchmark", FRAME_WIDTH, FRAME_HEIGHT, false);

		// load frames
		ResourceFactory f = ResourceFactory.getFactory();
		f.loadSheet(SPRITE_SHEET, SPRITE_SHEET_XML);
		String rscName = PaintableCanvas.loadStandardFrameResource(100, 100,
				JIGSHAPE.RECTANGLE, Color.black);
		bkgrdImage = ResourceFactory.getFactory().getFrames(rscName).get(2);
		
		statusText = f.getFontResource(new Font("Verdana", Font.BOLD, 14), Color.white, Color.black);
	}

	/** 
	 * Manipulates the benchmark parameters (read the explanation at the top 
	 * of this file) automatically (except for frame size). Each unique
	 * combination of parameters is called a configuration, or "config". Each 
	 * config will be ran RUNS_PER_CONFIG times to compute the avg and get the
	 * min and max.
	 */
	public void experiment1() {
		if (DISPLAY_SYSTEM_INFO) {
			displaySystemInfo();
		}
		long benchmkStartTime = System.nanoTime();
		ArrayList<TestSprite> theSprites = new ArrayList<TestSprite>();
		backgrounds.clear();

		// build list of TestSprites
		for (int j = 0; j < NUM_SPRITES; j++) {
			theSprites.add(new TestSprite(SHAPE_RSC));
		}

		useBackground = USE_BACKGROUND;
		rotate = ROTATE;
		
		run(theSprites, useBackground, rotate);

		long benchmkRunTime = System.nanoTime()- benchmkStartTime;
		System.out.println("\nBenchmark is done. Total benchmark run time: " + 
				(double)benchmkRunTime / GameClock.NANOS_PER_SECOND + " sec" +
				"\n(this value is NOT purely rendering time)");
	}
	
	
	/** 
	 * Does the actual rendering and timing.
	 */
	private void run(ArrayList<TestSprite> theSprites, boolean usingBackground,
			boolean rotate) {

		if(useBackground)
			backgrounds.add(new ImageBackgroundLayer(bkgrdImage,
				FRAME_WIDTH, FRAME_HEIGHT, BKGRD_DRAW_MODE));
		
		frame.setVisible(true);

		long totalRunTime = 0;
		long minRunTime = Long.MAX_VALUE;
		long maxRunTime = 0;

		// one iteration of this loop constitutes one complete "run".
		// one complete run is a unique "config" combination of frame size,
		// number of sprites, number of background images, and the boolean
		// rotate which dictates whether or not all sprites will be randomly
		// rotated.
		// a run is executed "RUNS_PER_CONFIG" times and the min, max, avg is
		// taken
		for (int i = 0; i < RUNS_PER_CONFIG; i++) {
			// start timing run
			long startRun = System.nanoTime();

			frame.displayBackBuffer();
			frame.clearBackBuffer();
			RenderingContext rc = frame.getRenderingContext();

			// render the background(s)
			for (ImageBackgroundLayer b : backgrounds) {
				b.render(rc);
			}
			// render each sprite in theSprites array
			for (TestSprite ts : theSprites) {
				ts.updateAndRender(rc, rotate);
			}
			//render status
			statusText.render("Please Wait " + (int)(i*100.0/RUNS_PER_CONFIG) + "%", rc, 
					AffineTransform.getTranslateInstance(FRAME_WIDTH/2.0-65, FRAME_HEIGHT/2.0-10));
			
			// stop timing run
			long endRun = System.nanoTime();
			long runTime = endRun - startRun;

			// keep track of min, max,
			minRunTime = (runTime < minRunTime ? runTime : minRunTime);
			maxRunTime = (runTime > maxRunTime ? runTime : maxRunTime);
			totalRunTime += runTime;
		}
		// compute average run time
		double avgRunTime = totalRunTime / RUNS_PER_CONFIG;

		// format results
		formatResults(minRunTime, maxRunTime, avgRunTime);
	}

	private void formatResults(long minRunTime, long maxRunTime,
			double avgRunTime) {
		long msn = GameClock.NANOS_PER_MS;

		Formatter f = new Formatter(System.out);
		long denom = (TIME_FORMAT == FPS || TIME_FORMAT == SEC) ? GameClock.NANOS_PER_SECOND : msn;
		String timeFormat = (TIME_FORMAT == FPS) ? "FPS" : (TIME_FORMAT == SEC) ? "s" : "ms";

		if (firstFormat) {
			System.out.println("RUNS_PER_CONFIG = " + RUNS_PER_CONFIG);
			
			f.format("%-10s %-8s %-11s %-7s %-14s %-14s %-14s\n", "res",
					"sprites", "background", "rotate", "avg(" + timeFormat
							+ ")", "min(" + timeFormat + ")", "max("
							+ timeFormat + ")");
			firstFormat = false;
		}
		double average = (avgRunTime / denom);
		double min = (double) minRunTime / denom;
		double max = (double) maxRunTime / denom;
		if(TIME_FORMAT == FPS)
		{
			average = 1.0 / average;
			min = 1.0 / min;
			max = 1.0 / max;
		}
		f.format("%-10s %-8d %-11b %-7b %-14.6f %-14.6f %-14.6f\n",
				FRAME_WIDTH + "x" + FRAME_HEIGHT, NUM_SPRITES,
				useBackground, rotate, average, min, max);
			
		logRuntime(Math.round(average*10)/10.0);
	}

	private class TestSprite extends Sprite {

		public TestSprite(String test) {
			super(test);
			// randomly pick a position
			// this sprite will keep that position for its life
			int x = (int) (Math.random() * (DrawingBenchmark.FRAME_WIDTH - width));
			int y = (int) (Math.random() * (DrawingBenchmark.FRAME_HEIGHT - height));
			position = new Vector2D(x, y);
		}

		public void updateAndRender(RenderingContext rc, boolean rotate) {
			double random = Math.random();

			// render one of the frames randomly
			setFrame((int) (random * frames.size()));
			Vector2D p = getCenterPosition();

			if (rotate) {
				AffineTransform at = AffineTransform.getTranslateInstance(p
						.getX(), p.getY());
				// rotate this sprite randomly
				at.rotate(random * 2 * Math.PI);
				render(rc, at);
			} else {
				render(rc);
			}
		}
	}


	public void logRuntime(double fps)
	{		
		Properties log = new Properties();
		
		FileInputStream in;
		try {
			in = new FileInputStream(jigBenchmarkFileName);
			log.load(in);
			in.close();
		} catch (FileNotFoundException e) {
			//Note: it is not required to have a custom game configuration
			//e.printStackTrace();
		} catch (IOException e) {
			//but we should probably know if this happens
			e.printStackTrace();
		}	
		
		String property = "";
		if(ConfigurationManager.getCurrentProperties().getProperty(ConfigurationManager.LWJGL_PROPERTY)
				.toLowerCase().equals("true"))
				property = LWJGL_LOG;
		else if(ConfigurationManager.getCurrentProperties().getProperty(ConfigurationManager.OPEN_GL_PROPERTY)
			.toLowerCase().equals("true"))
			property = OPEN_GL_LOG;
		else
			property = STANDARD_LOG;
				
		log.setProperty(property, "" + fps);
		
		try {
			log.store(new FileOutputStream(jigBenchmarkFileName), "JIG Benchmark Log");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	public void displaySystemInfo() {
		Properties pr = System.getProperties();
		TreeSet propKeys = new TreeSet(pr.keySet());
		for (Iterator it = propKeys.iterator(); it.hasNext();) {
			String key = (String) it.next();
			System.out.println("" + key + "=" + pr.get(key));
		}
		System.out.println();
	}
}
