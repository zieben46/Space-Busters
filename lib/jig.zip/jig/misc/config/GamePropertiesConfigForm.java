package jig.misc.config;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * A dialog to configure the JIG engine.
 * 
 * TODO: GamePropertiesConfigForm doesn't run from w/in eclipse.  Why not? 
 * TODO: Should at least have a note about when it can be run

 * @author James Van Boxtel
 * @author Scott Wallace
 * 
 */
@SuppressWarnings("serial")
final class GamePropertiesConfigForm extends JFrame implements ActionListener 
{
	JLabel description;
	
	JButton standard;
	JButton openGL;
	JButton LWJGL;
	
	JLabel openGLFPS;
	JLabel LWJGLFPS;
	JLabel standardFPS;
	
	JCheckBox defaults;
	JCheckBox fullscreen;
	JButton testConfig;
	
	JLabel empty;

	/**
	 * This variable is <code>true</code> until a button on the dialog has
	 * been pressed.
	 */
	volatile boolean waitingForInput;
	
	Properties properties;

	public static void main(String[] args)
	{
		GamePropertiesConfigForm gcd = new GamePropertiesConfigForm();

		while (gcd.waitingForInput) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// do nothing.
				continue;
			}
		}
	}

	/**
	 * Creates a configuration dialog based on the specified configuration.
	 * 
	 * @param initialConfiguration
	 *            the initial attempt at a configuration
	 */
	private GamePropertiesConfigForm() {
		super("JIG Graphics Configuration");
		
		this.addWindowListener(new java.awt.event.WindowAdapter() {
		    public void windowClosing(WindowEvent winEvt) {
		    	ConfigurationManager.saveGameProperties(properties);
		        System.exit(0); 
		    }
		});
		
		//get the current properties
		properties = ConfigurationManager.getCurrentProperties();

		//create the elements
		empty = new JLabel("");
		description = new JLabel("<html>Select one of the three buttons below" +
								 " and test the graphics configuration.<br />" +
								 " After the test runs, the average frames per" +
								 " second will be displayed.<br />" +
								 " Try to select a configuration" +
								 " with a high frame rate.</html>");
		standard = new JButton("Standard");
		openGL = new JButton("OpenGL");
		LWJGL = new JButton("LWJGL");
		standardFPS = new JLabel("Not Tested", JLabel.CENTER);
		openGLFPS = new JLabel("Not Tested", JLabel.CENTER);
		LWJGLFPS = new JLabel("Not Tested", JLabel.CENTER);
		defaults = new JCheckBox("Defaults");
		fullscreen = new JCheckBox("Fullscreen");
		testConfig = new JButton("Test Config");
		updateElements();

		//create the description panel
		JPanel descriptionPanel = new JPanel();
		descriptionPanel.add(description);
		
		//create the grid panel
		GridLayout layout1 = new GridLayout(0, 3);
		JPanel graphicsButtonsPanel = new JPanel(layout1);
		graphicsButtonsPanel.add(standard);
		graphicsButtonsPanel.add(openGL);
		graphicsButtonsPanel.add(LWJGL);
		graphicsButtonsPanel.add(standardFPS);
		graphicsButtonsPanel.add(openGLFPS);
		graphicsButtonsPanel.add(LWJGLFPS);
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(testConfig);
		graphicsButtonsPanel.add(fullscreen);
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(defaults);
		graphicsButtonsPanel.add(new JLabel(""));
		graphicsButtonsPanel.add(new JLabel(""));
		
		//add all the JPanels
		Container pane = getContentPane();
		pane.add(descriptionPanel, BorderLayout.NORTH);
		pane.add(graphicsButtonsPanel, BorderLayout.CENTER);
		
		pack();

		//add action listeners
		standard.addActionListener(this);
		openGL.addActionListener(this);
		LWJGL.addActionListener(this);
		defaults.addActionListener(this);
		fullscreen.addActionListener(this);
		testConfig.addActionListener(this);
		
		setVisible(true);
		waitingForInput = true;
	}
	
	public boolean isSet(String key)
	{
		return ((String)properties.getProperty(key)).toLowerCase().equals("true");
	}
	
	public void toggle(String key)
	{
		if(isSet(key))
			properties.put(key, "False");
		else
			properties.put(key, "True");
	}
	
	public void set(String key, boolean value)
	{
		properties.put(key, (value) ? "True" : "False");
	}

	public void updateElements()
	{
		Color disabledColor = Color.gray;
		Color enabledColor = Color.black;
		
		//set default values
		standard.setForeground(disabledColor);
		openGL.setForeground(disabledColor);
		LWJGL.setForeground(disabledColor);
		testConfig.setForeground(Color.blue);
		defaults.setForeground(disabledColor);
		fullscreen.setForeground(disabledColor);
		fullscreen.setSelected(false);
		defaults.setForeground(disabledColor);
		defaults.setSelected(false);
		
		//change if not default
		
		if(isSet(ConfigurationManager.FULLSCREEN_PROPERTY))
		{
			fullscreen.setForeground(enabledColor);
			fullscreen.setSelected(true);
		}
		else if(!isSet(ConfigurationManager.LWJGL_PROPERTY) && !isSet(ConfigurationManager.OPEN_GL_PROPERTY))
		{
			defaults.setForeground(enabledColor);
			defaults.setSelected(true);
		}

		if(isSet(ConfigurationManager.LWJGL_PROPERTY))
			LWJGL.setForeground(enabledColor);			
		else if(isSet(ConfigurationManager.OPEN_GL_PROPERTY))
			openGL.setForeground(enabledColor);
		else
			standard.setForeground(enabledColor);
		
		
		//check for FPS logs
		Properties log = new Properties();
		
		FileInputStream in;
		try {
			in = new FileInputStream(DrawingBenchmark.jigBenchmarkFileName);
			log.load(in);
			in.close();
		} catch (FileNotFoundException e) {
			//Note: it is not required to have a custom game configuration
			//e.printStackTrace();
		} catch (IOException e) {
			//but we should probably know if this happens
			e.printStackTrace();
		}	
		
		String logquery = log.getProperty(DrawingBenchmark.STANDARD_LOG);
		if(logquery != null)
			standardFPS.setText(logquery + " FPS");
		logquery = log.getProperty(DrawingBenchmark.OPEN_GL_LOG);
		if(logquery != null)
			openGLFPS.setText(logquery + " FPS");
		logquery = log.getProperty(DrawingBenchmark.LWJGL_LOG);
		if(logquery != null)
			LWJGLFPS.setText(logquery + " FPS");
		
	}

	
	/**
	 * Handles action events from the dialog's buttons.
	 * 
	 * @param arg0
	 *            the action event performed
	 */
	public void actionPerformed(final ActionEvent arg0) {
		if (arg0.getSource() == fullscreen) {
			toggle(ConfigurationManager.FULLSCREEN_PROPERTY);
		} else if (arg0.getSource() == defaults) {
			properties = ConfigurationManager.loadDefaultProperties();
		} if (arg0.getSource() == standard) {
			set(ConfigurationManager.OPEN_GL_PROPERTY, false);
			set(ConfigurationManager.LWJGL_PROPERTY, false);
		} else if (arg0.getSource() == openGL) {
			set(ConfigurationManager.OPEN_GL_PROPERTY, true);
			set(ConfigurationManager.LWJGL_PROPERTY, false);
		} else if (arg0.getSource() == LWJGL) {
			set(ConfigurationManager.OPEN_GL_PROPERTY, false);
			set(ConfigurationManager.LWJGL_PROPERTY, true);
		} else if(arg0.getSource() == testConfig) {
			saveAndRunTest();
		}
		
		updateElements();
	}

	public void saveAndRunTest()
	{
		ConfigurationManager.saveGameProperties(properties);
		        	
		/** DESIGN: We currently believe it is a reasonable assumption
		 * to assume java will be set up on the OS's class path */
        ///*
		try {
			String classPath = "lib/jig.jar;lib/ogg-spi/jogg-0.0.7.jar;lib/ogg-spi/jorbis-0.0.15.jar;lib/ogg-spi/tritonus_jorbis-0.3.6.jar;lib/spi/tritonus_share.jar;lib/lwjgl/jar/lwjgl_test.jar;lib/lwjgl/jar/lwjgl_util_applet.jar;lib/lwjgl/jar/lwjgl_util.jar;lib/lwjgl/jar/lwjgl.jar;lib/lwjgl/jar/jinput.jar";
			String defineFlags = "-Djava.library.path=lib/lwjgl/native/win32";
		
			Process p = Runtime.getRuntime().exec("java -cp \"" + classPath + "\" " + defineFlags + " jig.misc.config.DrawingBenchmark");
					
			if(p.waitFor() != 0)
			{
				JOptionPane.showMessageDialog(this,
						   "Unfortunately that configuration doesn't appear to work with this project.",
	                       "Configuration Manager Error",
	                       JOptionPane.ERROR_MESSAGE);
			}
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(this,
					   "The test could not be started.",
                       "Configuration Manager Error",
                       JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		//*/
		
	}
}



