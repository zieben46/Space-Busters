package jig.engine.lwjgl;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Hashtable;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.glu.GLU;

/**
 * 
 * OpenGL uses an RGBA image format. Since the images that are 
 * loaded from disk may not match this format this loader introduces
 * an intermediate image which the source image is copied into.
 * In turn, this image is used as source for the OpenGL texture.
 *
 * This version of the texture loader creates a texture that corresponds
 * to a single sprite, rather than loading an entire sprite sheet as
 * one large texture.
 * 
 * Portions of this code were borrowed from the LWJGL project's example code.
 * 
 * @author Andrew Nierman
 */
class TextureLoader {
    //The color model for the OpenGL image
    private ColorModel glColorModel;

    //The color model including alpha for the OpenGL image
    private ColorModel glAlphaColorModel;
    
    /** 
     * Create a new texture loader.
     */
    public TextureLoader() {
        glAlphaColorModel = new ComponentColorModel(
        		ColorSpace.getInstance(ColorSpace.CS_sRGB),
                                            new int[] {8, 8, 8, 8},
                                            true,
                                            false,
                                            ComponentColorModel.TRANSLUCENT,
                                            DataBuffer.TYPE_BYTE);
                                            
        glColorModel = new ComponentColorModel(
        		ColorSpace.getInstance(ColorSpace.CS_sRGB),
                                            new int[] {8, 8, 8, 0},
                                            false,
                                            false,
                                            ComponentColorModel.OPAQUE,
                                            DataBuffer.TYPE_BYTE);
    }
    
    /**
     * Return a unique integer ID for a texture (using OpenGL's glGenTextures).
     * 
     * @return A texture ID
     */
    private int createTextureID() {
        IntBuffer buffer = BufferUtils.createIntBuffer(1);
        GL11.glGenTextures(buffer);
        return buffer.get(0);
    }
    
	/**
	 * Sets up the appropriate texture in OpenGL, corresponding to the input
	 * image and returns a texture object that can be used to render the
	 * texture.
	 * 
	 * @param bufferedImage the original image
	 * @param transparency the desired transparency
	 * @param width the width of the resulting image resource
	 * @param height the height of the resulting image resource
	 * @param xOffset the x offset within the original image where the sub-image
	 * of interest is located
	 * @param yOffset the y offset within the original image where the sub-image
	 * of interest is located
	 * @return a texture object representing the desired image resource, with
	 * the appropriate OpenGL context having been set
	 */
    public Texture getTexture(final BufferedImage bufferedImage,
    		final int transparency, final int width, final int height,
    		final int xOffset, final int yOffset) {
    	
        int srcPixelFormat;
        int dstPixelFormat = GL11.GL_RGBA;
        
        // create the unique texture ID for this texture 
        int textureID = createTextureID();
        
        // bind this texture 
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID); 
        
        if (bufferedImage.getColorModel().hasAlpha()) {
            srcPixelFormat = GL11.GL_RGBA;
        } else {
            srcPixelFormat = GL11.GL_RGB;
        }

        Texture texture = new Texture(textureID, width, height);

        // convert the image into a byte buffer of texture data
        ByteBuffer textureBuffer = convertImageData(bufferedImage,
        		texture, width, height, xOffset, yOffset, srcPixelFormat); 

        GL11.glTexParameteri(GL11.GL_TEXTURE_2D,
        		GL11.GL_TEXTURE_MIN_FILTER,
        		GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D,
        		GL11.GL_TEXTURE_MAG_FILTER,
        		GL11.GL_LINEAR);

        // note: newer wrapping modes include:
        // GL13.GL_CLAMP_TO_BORDER and GL12.GL_CLAMP_TO_EDGE

        GL11.glTexParameteri(GL11.GL_TEXTURE_2D,
        		GL11.GL_TEXTURE_WRAP_S,
        		GL11.GL_REPEAT);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D,
        		GL11.GL_TEXTURE_WRAP_T,
        		GL11.GL_REPEAT);
        
        // produce a texture from the byte buffer
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D,
                      0,
                      dstPixelFormat,
                      texture.getTextureWidth(),
                      texture.getTextureHeight(),
                      0,
                      srcPixelFormat,
                      GL11.GL_UNSIGNED_BYTE,
                      textureBuffer);
        
        return texture; 
    }
    
    /**
     * Convert a buffered image to a ByteBuffer that is appropriate for use
     * with the OpenGL texture commands.
     *
     * @param bufferedImage The image to convert
     * @param texture The associated texture object
     * @param width width of the image
     * @param height height of the image
     * @param xOffset xOffset within the image
     * @param yOffset yOffset within the image
     * @param srcPixelFormat the format of the image file (GL_RGB or GL_RGBA)
     * @return A buffer containing the texture data
     */
    private ByteBuffer convertImageData(final BufferedImage bufferedImage,
    		final Texture texture, 
    		final int width, final int height,
    		final int xOffset, final int yOffset,
    		final int srcPixelFormat) {
    	
        ByteBuffer imageBuffer = null; 
        WritableRaster raster;
        BufferedImage texImage;
        
        // create a raster that can be used by OpenGL as a source for a texture
        if (bufferedImage.getColorModel().hasAlpha()) {
            raster = Raster.createInterleavedRaster(
            		DataBuffer.TYPE_BYTE, width, height, 4, null);
            texImage = new BufferedImage(
            		glAlphaColorModel, raster, false,
            		new Hashtable<Object, Object>());
        } else {
            raster = Raster.createInterleavedRaster(
            		DataBuffer.TYPE_BYTE, width, height, 3, null);
            texImage = new BufferedImage(
            		glColorModel, raster, false,
            		new Hashtable<Object, Object>());
        }
        
        // put the portion of the image that we're interested in into texImage
        Graphics g = texImage.getGraphics();
        g.setColor(new Color(0f, 0f, 0f, 0f));
        g.fillRect(0, 0, width, height);
        g.drawImage(bufferedImage, -xOffset, -yOffset, null);
        
        // build a byte buffer from the temporary image 
        // that be used by OpenGL to produce a texture.
        byte[] data =
        	((DataBufferByte) texImage.getRaster().getDataBuffer()).getData(); 

        // gluScaleImage requires us to add some extra space to the buffers
        // when the width times the number of components for each value is not
        // divisible by 4.
        // since RGB mode has 3 components, we add space here.
        int extraInSpace = 0;
        if (srcPixelFormat == GL11.GL_RGB) {
        	extraInSpace = 4 * height;
        }
        
        imageBuffer = BufferUtils.createByteBuffer(data.length + extraInSpace);
        imageBuffer.put(data, 0, data.length);
        //imageBuffer.flip(); // don't flip, may need the extra space, so rewind
        imageBuffer.rewind();
        
        int texWidth = texture.getTextureWidth();
        int texHeight = texture.getTextureHeight();

        // if needed, scale the image dimensions to be a power of two with gluScaleImage        
        if (texWidth != width || texHeight != height) {
            int scaledLength = ((srcPixelFormat==GL11.GL_RGBA)?4:3)
	        	* texWidth * texHeight;
            
            // TODO the extra space is needed for the input buffer. need to
            // verify that it is needed for the output buffer as well.
            // there is no documentation in the lwjgl api docs for gluScaleImage
            int extraOutSpace = 0;
            if (srcPixelFormat == GL11.GL_RGB) {
            	extraOutSpace = 4 * texHeight;
            }

	        ByteBuffer scaledBuffer = BufferUtils.createByteBuffer(scaledLength + extraOutSpace);
	        
	        GLU.gluScaleImage(srcPixelFormat,
	        		width, height, GL11.GL_UNSIGNED_BYTE, imageBuffer,
	        		texWidth, texHeight, GL11.GL_UNSIGNED_BYTE, scaledBuffer);
        
	        return scaledBuffer;
        }
        
        return imageBuffer;
    }
}
