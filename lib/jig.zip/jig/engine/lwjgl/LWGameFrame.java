package jig.engine.lwjgl;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.font.FontRenderContext;
import java.awt.font.LineMetrics;
import java.awt.geom.AffineTransform;
import java.nio.DoubleBuffer;
import java.nio.IntBuffer;
import java.util.Iterator;
import java.util.logging.Logger;

import jig.engine.Console;
import jig.engine.FontResource;
import jig.engine.GameFrame;
import jig.engine.RenderingContext;
import jig.engine.ResourceFactory;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

/**
 * A concrete Game Frame class for the LWJGL backend.
 * 
 * @author Andrew Nierman
 * 
 */
final class LWGameFrame implements GameFrame {

	private RenderingContext renderingContext;
	private LWKeyboard keyboard;
	private LWMouse mouse;
	private LWGameFrame.LWConsole console;
	private int fullscreenPixelWidth = 0, fullscreenPixelHeight = 0;
	private int windowXPosition, windowYPosition;
	private Logger logger;
	private int width;
	private int height;
	private boolean fullscreen;
	private DisplayMode fullscreenCompatibleMode;
	private int screenBitDepth, screenRefreshRate;
	// TODO test replacement of fullscreenPixel* with screenWidth/Height
	//private int screenWidth, screenHeight;
	private ExitHandler exitHandler;
	volatile boolean closeAndExitOnNextRender = false;

	/**
	 * Creates a GameFrame consistent with the specified jig configuration.
	 * 
	 * @param title the title of the frame (note this is not visible in
	 * full screen mode or with undecorated windows)
	 * @param gameConfiguration a JigeGC configuration object
	 */
	public LWGameFrame(final String title, final int w, final int h,
			final boolean preferredFullScreen) {
		
		logger = ResourceFactory.getJIGLogger();
		
		GraphicsEnvironment genv = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gdev = genv.getDefaultScreenDevice();
		java.awt.DisplayMode gdsplymode = gdev.getDisplayMode();
		
		// TODO the window position should probably be part of the JigGC object
		// position values of -1 cause LWJGL to center the window initially
		windowXPosition = -1;
		windowYPosition = -1;
		Display.setLocation(windowXPosition, windowYPosition);
		
		width = w;
		height = h;
		fullscreen = preferredFullScreen;

		// grab the current operating system settings related to the display:
		screenBitDepth = gdsplymode.getBitDepth();
		screenRefreshRate = gdsplymode.getRefreshRate();
		//screenWidth = gameConfig.getInitialDisplayMode().getWidth();
		//screenHeight = gameConfig.getInitialDisplayMode().getHeight();
		
		setupDisplay();
		
		logger.info("LWJGL Version: " + org.lwjgl.Sys.getVersion());
		//logger.info("Graphics Card: " + Display.getAdapter());
		//logger.info("Graphics Card Driver Version: " + Display.getVersion());
		logger.info("OpenGL Version: " + GL11.glGetString(GL11.GL_VERSION));

		console = new LWConsole(w,
				h / 4,
				0.6f, this);

		//hide the cursor:
		//org.lwjgl.input.Mouse.setGrabbed(true);
		
		Display.setTitle(title);
		
		// enable textures. they are used for our sprites
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		// we use GL_REPLACE mode for our texture mapping, which replaces any
		// color or shading information with the texture data
		// if we ever include lighting or shading effects, may want to switch
		// to GL_MODULATE
		GL11.glTexEnvi(GL11.GL_TEXTURE_ENV, GL11.GL_TEXTURE_ENV_MODE,
				GL11.GL_REPLACE);
		
		// we're just doing 2D graphics, so disable depth testing:
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		//GL11.glEnable(GL11.GL_DEPTH_TEST);
		//GL11.glClearDepth(1.0f);
		//GL11.glDepthFunc(GL11.GL_LEQUAL);

		// enable alpha blending for transparency/translucency
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

		// since the ortho view below is "upside down", we change the front
		// facing polygons to be clockwise ordered, so culling will work as
		// expected with the standard counter clockwise ordering of vertices
		//GL11.glEnable(GL11.GL_CULL_FACE);
		//GL11.glFrontFace(GL11.GL_CW);

		GL11.glMatrixMode(GL11.GL_PROJECTION);
		GL11.glLoadIdentity();

		// set set up the viewing volume "upside down" to match the java 2d
		// side of things, where (0, 0) is the top left rather than bottom left:
		// glOrtho(left, right, bottom, top, zNear, zFar)
		GL11.glOrtho(0, w,
				h, 0, -1, 5);
		
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();

		// black background:
		//GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
		// white background:
		GL11.glClearColor(1.0f, 1.0f, 1.0f, 0.0f);
		
		clearBackBuffer();
		Display.update();
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @param visible
	 *            <code>true</code> iff the frame should be made visible.
	 *            
	 * TODO not sure how to best implement this with LWJGL.
	 */
	public void setVisible(final boolean visible) { }


	
	/**
	 * {@inheritDoc}
	 */
	public void displayBackBuffer() {
		// since we're not using listeners on the lwjgl side, we put a
		// check for window closing here, where it will be called each time
		// through the rendering loop
		if (Display.isCloseRequested()) {
			requestExitAndClose(false);
		}

		// workaround for the "high fps" but slow game rendering for pong
		// (problem was only observed on one test machine so far, and the
		// Display.setVSyncEnabled(true); call had no effect on that machine
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		// TODO the LWJGL engine has three sync methods. need to look at the
		//code for these, as they make the pong game just a bit choppy,
		// whereas the simple sleep(1) above is smooth.
		//Display.sync3(screenRefreshRate);
		
		console.renderToBackBuffer();

		// update calls swapBuffers, so no need to call that explicitly
		Display.update();
	}

	/**
	 * {@inheritDoc}
	 */
	public RenderingContext getRenderingContext() {
		if (renderingContext == null) {
			renderingContext = new LWRenderingContext();
		}
		return renderingContext;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * {@inheritDoc}
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * {@inheritDoc}
	 */
	public void setTitle(final String title) {
		Display.setTitle(title);
	}

	/**
	 * {@inheritDoc}
	 */
	public void clearBackBuffer() {
		// don't need to clear the depth buffer (GL11.GL_DEPTH_BUFFER_BIT),
		// since we have disabled depth buffering. just clear the color buffer.
		
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
	}

	/**
	 * {@inheritDoc}
	 */
	public jig.engine.Keyboard getKeyboard() {
		if (keyboard == null) {
			return new LWKeyboard(this);
		}
		return keyboard;
	}
	
	/**
	 * {@inheritDoc}
	 */
	public jig.engine.Mouse getMouse() {
		if (mouse == null) {
			mouse = new LWMouse(this);
		}
		return mouse;
	}

	/**
	 * Initializes the LWJGL display based on the dimensions and full screen
	 * mode that were received as input parameters. Vertical sync is also
	 * enabled in this method.
	 * 
	 * @param w the width of the new window
	 * @param h the height of the new window
	 * @param fullscreenMode true if the display should be full screen, false
	 * if it should be opened in windowed mode initially.
	 */
	private void setupDisplay() {
		
		
		Display.setVSyncEnabled(true);

		// store a compatible fullscreen display mode:
		fullscreenCompatibleMode = getFullscreenDisplayMode();
		
		try {
			Display.setFullscreen(fullscreen);
			if (fullscreenCompatibleMode == null && fullscreen == false) {
				// if we could not find a compatible full screen mode, just
				// create a display mode here for windowed mode
				// note: when switching to full screen with this mode windows
				// will position the window in the lower left corner, taking
				// up part of the screen, macos will actually stretch the window
				// to fit the screen
				DisplayMode mode = new DisplayMode(width, height);
				Display.setDisplayMode(mode);
			} else {
				Display.setDisplayMode(fullscreenCompatibleMode);
			}
			
			Display.create();
		} catch (LWJGLException e) {
			logger.severe("Error setting up the LWJGL display w/ params:\n"
					+ fullscreenCompatibleMode.toString()
					+ e.getMessage());
			System.exit(0);
		}
	}

	/**
	 * Return a compatible full screen display mode based on the height
	 * and width used to initialize the game frame.
	 * @return a full screen display mode
	 * 
	 * DESIGN if we allow switching of display dimensions at some point,
	 * will need to change this method.
	 * 
	 * TODO in windows (with my current drivers), if a fullscreen
	 * mode is found that is "compatible" but has a different bpp
	 * than the windows desktop, then switching to fs mode causes
	 * a crash, this doesn't happen on the mac
	 * 
	 */
	private DisplayMode getFullscreenDisplayMode() {

		if (fullscreenCompatibleMode != null) {
			return fullscreenCompatibleMode;
		} else {
			try {
				// getAvailableDisplayModes() returns compatible full screen modes
				DisplayMode[] modes = Display.getAvailableDisplayModes();
				for (DisplayMode mode : modes) {
					if (mode.getWidth() == getWidth()
							&& mode.getHeight() == getHeight()
							&& mode.getFrequency() == screenRefreshRate
							&& mode.getBitsPerPixel() == screenBitDepth) {
						return mode;
					}
				}
			} catch (LWJGLException e) {
				logger.severe("Error fetching available display modes:\n"
						+ e.getMessage());
				System.exit(0);
			}
		}
		
		logger.info("no compatible fullscreen display modes for "
				+ "width = " + getWidth()
				+ ", height = " + getHeight()
				+ ", refresh rate = " + screenRefreshRate
				+ ", bpp= " + screenBitDepth);
		
		return null;
	}
	
	/**
	 * Returns the width in pixels in full screen mode. This is used by the
	 * {@link LWMouse} class since the mouse position in full screen results
	 * in different coordinates for game objects than in windowed mode.
	 * 
	 * @return the width of the window in pixels when in full screen mode
	 */
	public int getFullscreenPixelWidth() {
		return fullscreenPixelWidth;
	}

	/**
	 * Returns the height in pixels in full screen mode. This is used by the
	 * {@link LWMouse} class since the mouse position in full screen results
	 * in different coordinates for game objects than in windowed mode.
	 * 
	 * @return the height of the window in pixels when in full screen mode
	 */
	public int getFullscreenPixelHeight() {
		return fullscreenPixelHeight;
	}
	
	/**
	 * @return a static reference to the game frame's command console
	 * 
	 * DESIGN not static at the moment.
	 */
	public Console getConsole() {
		return console;
	}


	public void registerExitHandler(ExitHandler exitHandler) {
		this.exitHandler = exitHandler;
	}
	
	/**
	 * LWJGL's Rendering Context.
	 * 
	 * Note that this class requires us to map between OpenGL transformation
	 * matrices and the transformations internal to the Java
	 * <code>AffineTransform</code> class.
	 * 
	 * Both representations expect (and return) values in column-major order.
	 * 
	 * Since the AffineTransform class works with 2D transforms only, it uses a
	 * 3x3 matrix and only 6 values are specified (or returned). These values
	 * are shown below as mrc, where r is the row and c is the column in the
	 * matrix. The final row is always <0 0 1>:
	 * 
	 * <pre>
	 * | m00  m01  m02 |
	 * | m10  m11  m12 |
	 * |  0    0    1  |
	 * </pre>
	 * 
	 * So an array of values would be given (returned) in the order:
	 * [ m00 m10 m01 m11 m02 m12 ]
	 * 
	 * The OpenGL matrix is also expected (returned) in column-major order, but
	 * it is a full 4x4 matrix. In order to generate the same transform the
	 * corresponding values from above will be placed in the opengl matrix as
	 * follows:
	 * 
	 * <pre>
	 * | m00  m01   0   m02 |
	 * | m10  m11   0   m12 |
	 * |  0    0    1    0  |
	 * |  0    0    0    1  |
	 * </pre>
	 * 
	 * An array of these values would be given (returned) in the order:
	 * [ m00 m10 0 0 m01 m11 0 0 0 0 1 0 m02 m12 0 1 ]
	 * so we will be interested in the 0, 1, 4, 5, 12, and 13 indices
	 * when reading values from the OpenGL matrix.
	 * 
	 * @author Andrew Nierman
	 */
	public class LWRenderingContext implements RenderingContext {

		// originally, I was creating a new buffer inside each of the methods
		// where it was needed, but the buffer falls outside of the normal
		// java garbage collection process. in particular,
		// the buffer object was not getting garbage collected until the
		// garbage collector did a "full GC" and got rid of objects in
		// the "tenured" heap area. this causes a noticeable periodic
		// stutter in the game
		// so, now we have a single buffer as a member variable that is
		// re-used (and cleared) in each method as needed. the code is not
		// quite as readable, and slightly more error prone, but performance
		// is substantially improved
		private DoubleBuffer buffer = BufferUtils.createDoubleBuffer(16);
		
		// also keeping an array buffer to for this matrix
		private double[] matrixBuffer = new double[6];
				
		/**
		 * Returns the current global affine transformation that is applied
		 * to all visible objects
		 * @return the current transform
		 */
		public AffineTransform getTransform() {
			// retrieve and store the current OpenGL matrix
			GL11.glGetDouble(GL11.GL_MODELVIEW_MATRIX, buffer);

			// create the corresponding AffineTransformation object
			AffineTransform a = new AffineTransform(buffer.get(0), buffer.get(1),
					buffer.get(4), buffer.get(5), buffer.get(12), buffer.get(13));
			
			buffer.rewind();
			
			return a;
		}

		/**
		 * Sets the global affine transformation used to render all visible
		 * objects to the game frame's drawing surface.
		 * 
		 * @param at the new affine transform
		 */
		public void setTransform(final AffineTransform at) {
			affineTransformToDoubleBuffer(at);
			// overwrite the current (modelview) matrix
			GL11.glLoadMatrix(buffer);
			buffer.rewind();
		}

		/**
		 * Composes an affine transform with the current global transform
		 * according to the rule last-specified-first-applied. The new global
		 * transform is applied to all visible objects.
		 * 
		 * @param at
		 *            the transform to be composed with the current transform
		 */
		public void transform(final AffineTransform at) {
			affineTransformToDoubleBuffer(at);
			// post-muliply the current matrix with the matrix stored in buffer
			GL11.glMultMatrix(buffer);
			buffer.rewind();
		}

		/**
		 * 
		 * @param at a Java AffineTransform object to store into our buffer object
		 */
		private void affineTransformToDoubleBuffer(
				final AffineTransform at) {

			// we're going to keep this as a member variable, since there are a
			// lot of them to create. it's worse in terms of code design, but
			// improves performance since this method is called so frequently
			//double[] matrixBuffer = new double[6];
			
			// retrieve the 6 values (first two rows) of the 3x3 matrix
			at.getMatrix(matrixBuffer);

			// store these 6 values into a buffer representing a
			// a column major 4x4 opengl matrix

			// column 1:
			buffer.put(matrixBuffer[0]);
			buffer.put(matrixBuffer[1]);
			buffer.put(0);
			buffer.put(0);

			// column 2:
			buffer.put(matrixBuffer[2]);
			buffer.put(matrixBuffer[3]);
			buffer.put(0);
			buffer.put(0);

			// column 3:
			buffer.put(0);
			buffer.put(0);
			buffer.put(1);
			buffer.put(0);

			// column 4:
			buffer.put(matrixBuffer[4]);
			buffer.put(matrixBuffer[5]);
			buffer.put(0);
			buffer.put(1);

			//buffer.flip();
			buffer.rewind();
		}

	} // LWRenderingContext

	/**
	 * The Console for an LWGameFrame.
	 * 
	 * @author Andrew Nierman
	 * @see Console
	 */
	class LWConsole extends Console {
		private int consoleWidth, consoleHeight;
		private float red, green, blue;
		private float alpha;

		private int lineHeight;
		//private int lineDescent;
		
		private Font font;
		private LineMetrics metrics;
		private FontResource bitmapFont;

		//private int renderedBufferVersion;
		
		/**
		 * Creates a new LWConsole for the GameFrame.
		 * 
		 * @param red the red component of the console,
		 * ranges from 0 (none) to 1
		 * @param green the green component of the console, ranges from 0 to 1
		 * @param blue the blue component of the console, ranges from 0 to 1
		 * @param w the console width
		 * @param h the console height
		 * @param alpha the translucency of the console. a value of 0 indicates
		 * full transparency, while a value of 1 indicates an opaque console
		 * @param fontSize the points size of the font to be used in the console
		 */
		public LWConsole(final float red, final float green, final float blue,
				final int w, final int h, final float alpha,
				final int fontSize, GameFrame frame) {
			super(frame);
			this.red = red;
			this.green = green;
			this.blue = blue;
			
			consoleWidth = w;
			consoleHeight = h;
			this.alpha = alpha;

			font = new Font("SanSerif", Font.PLAIN, fontSize);
			bitmapFont =
				ResourceFactory.getFactory().getFontResource(font, Color.black, null);
			
			metrics = getLineMetrics(font);
			// line height is calculated as the ascent + descent + leading
			lineHeight = (int) Math.ceil(metrics.getHeight());
			//lineDescent = (int) Math.ceil(metrics.getDescent());
			
			int numLines = consoleHeight / lineHeight;
			// set the buffer size equal to the number of lines that will fit
			// minus 1, to leave space for the input line
			setBufferSize(numLines - 1);
			
			// render the console buffer the first time through
			//renderedBufferVersion = consoleBuffer.getTextVersion() - 1;
			
	
		}
		
		/**
		 * Creates a new LWConsole for the GameFrame.
		 * 
		 * @param w the console width
		 * @param h the console height
		 * @param alpha the translucency of the console. a value of 0 indicates
		 */
		public LWConsole(final int w, final int h, final float alpha, GameFrame frame) {
			// default color is yellow (red + green), with a font size of 12
			this(1.0f, 1.0f, 0.0f, w, h, alpha, 12, frame);
		}
		
		/**
		 * Calculate metrics (descent, ascent, leading) for the current font.
		 * 
		 * @param f the current font to analyze for metric information
		 * @return the metric information for the font as a LineMetrics object
		 */
		private LineMetrics getLineMetrics(final Font f) {
			// generate a string of all of the available characters
			StringBuffer sb = new StringBuffer(256);
			for (int i = 0; i <= 255; i++) {
				sb.append((char) i);
			}

			// hmmm... on second thought, if we use all of the possible
			// characters then the line height is probably going to be equal
			// to the font "size" (10 point, 12 point, etc),
			// so this is probably just extra work.
			// although it is only called in the constructor
			
			// and return metrics for this line
			return f.getLineMetrics(sb.toString(),
					new FontRenderContext(new AffineTransform(),
							true, true));
		}
		


		/**
		 * {@inheritDoc}
		 */
		@Override
		public void renderToBackBuffer() {
			if (visible) {
				//render the yellow translucent console rectangle first:
				
				GL11.glDisable(GL11.GL_TEXTURE_2D);
						
				// save the current drawing color
				GL11.glPushAttrib(GL11.GL_CURRENT_BIT);

				GL11.glColor4f(red, green, blue, alpha);
				
				GL11.glBegin(GL11.GL_QUADS);
				
				GL11.glVertex3i(0, 0, 1);
				GL11.glVertex3i(0, consoleHeight, 1);
				GL11.glVertex3i(consoleWidth, consoleHeight, 1);
				GL11.glVertex3i(consoleWidth, 0, 1);
				
				GL11.glEnd();
				
				// restore the current drawing color
				GL11.glPopAttrib();
				
				GL11.glEnable(GL11.GL_TEXTURE_2D);
				
				
				// now render the text in the console buffer:
				
				int y = consoleHeight
					- ((size() + 1) * lineHeight);

				for (Iterator<String> s = lines();
					s.hasNext();) {
					for (int x = 0; x < columns; x++) {
						bitmapFont.render(s.next(), renderingContext,
								AffineTransform.getTranslateInstance(
										x * (getWidth() / columns), y));
					}
					y += lineHeight;
				}
				
				bitmapFont.render(workingLine(), renderingContext,
						AffineTransform.getTranslateInstance(0, y));

				// not currently using renderedBufferVersion, although I could
				// send the above console output into a pixel buffer and just
				// blit that rather than stepping through the console buffer
				// each time when there are no changes
				//renderedBufferVersion = consoleBuffer.getTextVersion();
			}
		}

	} // class LWConsole


	public boolean getFullScreen() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean toggleFullscreenMode() {
		if(!Display.isFullscreen()) {
			try {
				// we should grab the current window position in case of a
				// switch back to windowed mode later.
				// otherwise the window pops back
				// to whatever location was initially given with setLocation
				
				// TODO a call to glGetInteger(GL_VIEWPORT) returned
				// values of (0, 0) for x and y each time,
				// although the width and height values were correct
				// need to debug this
				//windowXPosition = viewportInfo.get(0);
				//windowYPosition = viewportInfo.get(1);
				
				// switch to full screen mode
				Display.setFullscreen(true);
				
				// glGetInteger used with GL_VIEWPORT will return four int
				// values, x position, y position, width, and height
				IntBuffer viewportInfo = BufferUtils.createIntBuffer(16);
				GL11.glGetInteger(GL11.GL_VIEWPORT, viewportInfo);
				
				fullscreenPixelWidth = viewportInfo.get(2);
				fullscreenPixelHeight = viewportInfo.get(3);
				
			} catch (LWJGLException e) {
				logger.info("could not switch to full screen mode.");
				return false;
			}
		}
		else if(Display.isFullscreen()) {
			try {
				// if we were not able to find a fullscreen mode
				// then we need to reset the dimensions of the window
				// when returning... otherwise the window stays at the
				// full screen dimensions.
				if (fullscreenCompatibleMode == null) {
					DisplayMode mode = new DisplayMode(getWidth(), getHeight());
					Display.setDisplayMode(mode);
				}
				Display.setFullscreen(false);
				
				// restore the window to its previous location
				// Display.setLocation(windowXPosition, windowYPosition);
				
			} catch (LWJGLException e) {
				logger.info("could not switch to windowed mode.");
				return false;
			}
		}
		
		return true;
	}


	public boolean requestExitAndClose(boolean forcedExit) {
		if(!forcedExit && exitHandler != null &&
				!exitHandler.handleRequestedExit())
		{
			return false;
		}
		closeAndExitOnNextRender = true;
		return true;
	}
	
	public boolean isExitAndCloseRequested() {
		return closeAndExitOnNextRender;
	}
		
	/**
	 * {@inheritDoc}
	 */
	public void closeAndExit() {
		Display.destroy();
		System.exit(0);
	}
	

	
} // class LWGameFrame
