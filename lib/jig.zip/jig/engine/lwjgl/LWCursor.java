package jig.engine.lwjgl;

import java.nio.IntBuffer;

import jig.engine.CursorResource;
import jig.engine.util.Vector2D;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Cursor;

/**
 * This class is basically just a wrapper for the {@link org.lwjgl.input.Cursor}
 * class. It already implements all of the functionality we will need.
 * 
 * @author Andrew Nierman
 * @author Aaron Mills
 * 
 */
class LWCursor implements CursorResource {
	private String name;
	private long animationDelay;
	private Vector2D hotSpot;
	//private int yHotSpot;
	private Cursor lwjglCursor;

	// TODO should probably receive the images as list of ImageResource objects
	// (rather than an IntBuffer) to be a bit friendlier to the caller
	public LWCursor(String name, int width, int height,
			int xHotSpot, int yHotSpot,
			int numImages, IntBuffer images, int animationDelay)
			throws LWJGLException {
	
		this.name = name;
		this.animationDelay = animationDelay;
		this.hotSpot = new Vector2D(xHotSpot, yHotSpot);
		
		IntBuffer delays = BufferUtils.createIntBuffer(numImages);
		// based on the CursorResource interface, all of the delays are the same
		for (int i = 0; i < numImages; i++) {
			delays.put(animationDelay);
		}
		delays.flip();

		lwjglCursor = new Cursor(width, height, xHotSpot, yHotSpot,
				numImages, images, delays);		
	}

	public long getAnimationDelay() {
		return animationDelay;
	}

	public Vector2D getHotSpot() {
		return hotSpot;
	}

	public String getName() {
		return name;
	}
	
	public Cursor getLwjglCursor() {
		return lwjglCursor;
	}
}
