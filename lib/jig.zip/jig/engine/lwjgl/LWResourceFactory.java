package jig.engine.lwjgl;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;

import jig.engine.CursorResource;
import jig.engine.FontResource;
import jig.engine.GameFrame;
import jig.engine.ImageResource;
import jig.engine.ResourceFactory;
import jig.engine.util.Vector2D;

/**
 * A resource factory for the Lightweight Java Gaming Library (LWJGL).
 * 
 * Currently, the JIG-E's Java 2D resource factory is an alternative to LWJGL.
 * LWJGL performance is generally better, but J2D is 100% Java.
 * 
 * @see jig.engine.j2d.J2DResourceFactory
 * 
 * @author Andrew Nierman
 *
 */
public final class LWResourceFactory extends ResourceFactory {
	/** The single LWJGL game frame, if one has been created. */
	private LWGameFrame frame;	
	private TextureLoader textureLoader;

	/**
	 * Creates the singleton instance of the factory.
	 */
	private LWResourceFactory() {
		super();
		frame = null;
		textureLoader = new TextureLoader();
	};

	/**
	 * Makes an instance of the LWResourceFactory the current,
	 * canonical, resource factory. Once the canonical factory
	 * is set, it cannot be changed for the life of the application.
	 *
	 * @see ResourceFactory#getFactory()
	 * @see ResourceFactory#setCurrentResourceFactory(ResourceFactory)
	 */
	public static void makeCurrentResourceFactory() {
		//Design: Figure out what to do with GameClock
		//Timer.setTimerClass(new LWTimer());
		ResourceFactory.setCurrentResourceFactory(new LWResourceFactory());
	}

	/**
	 * Creates a new ImageResource as an OpenGL Texture.
	 * 
	 * @param originalImg the original image
	 * @param transparency the desired transparency mode
	 * @param w the width of the resulting image resource
	 * @param h the height of the resulting image resource
	 * @param xoffset the xoffset of the resulting image with
	 *        respect to the original image
	 * @param yoffset the yoffset of the resulting image with
	 *        respect to the original image
	 * @return a new 'internally formatted' image resource
	 */
	@Override
	protected ImageResource createImageResource(final BufferedImage originalImg,
			final int transparency, final int w, final int h, 
			final int xoffset, final int yoffset) {

//		return new J2DImage(originalImg, transparency, w, h, -xoffset,
//				-yoffset, frame);
		return textureLoader.getTexture(originalImg,
				transparency, w, h, xoffset, yoffset);
	}
	
	/**
	 * Creates a container for displaying the game.
	 *  
	 * @param title the name to display on the frame (if applicable)
	 * @param graphicsConfig a JIG-E graphics configuration
	 * 
	 * @return a container within which the game can be rendered
	 */
	@Override
	public GameFrame getGameFrame(final String title, final int w, final int h,
			final boolean preferredFullScreen) {
		if (frame == null) {
			
			try {
				//frame = LWGameFrame.getGameFrame(title, graphicsConfig);
				//return frame;
				frame = new LWGameFrame(title, w, h, preferredFullScreen);
			} catch (UnsatisfiedLinkError e) {
				//LWJGL libs must not be included so lets ignore this option
				throw new IllegalStateException("Could not run in LWJGL mode because the correct libraries are not included. " +
													"Make sure the LWJGL jars are in the directory and on the classpath. " +
													"You must also set the correct native library as a define flag.");
			}
			
		} else {
			throw new RuntimeException("Only one game frame can exist...");
		}
		
		return frame;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public FontResource getFontResource(final Font f, Color fontColor, Color backgroundColor) {
		return getBitmapFont(f, fontColor, backgroundColor);
	}

	@Override
	public FontResource getFontResource(final Font f, Color fontColor, Color backgroundColor, boolean prioritzeSpeed) {
		return getBitmapFont(f, fontColor, backgroundColor);
	}

	@Override
	public CursorResource makeCursor(String rscName, Vector2D hotspot,
			long delay) {
		// TODO ANDY MERGE Actually add support for custom cursors
		return null;
	}
}
