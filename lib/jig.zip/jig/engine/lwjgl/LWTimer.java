package jig.engine.lwjgl;

import jig.engine.GameClock;
import jig.engine.GameClock.TimeManager;

/**
 * A Timer class that wraps the LWJGL Timing facility.
 * 
 * @author Scott Wallace
 * @author James Van Boxtel
 * 
 * TODO: Verify this class has been updated to use the new GameClock
 * correctly. Also verify it is actually needed, and figure out where
 * the GameClock.setManager method should be called.
 *
 */
class LWTimer implements TimeManager {
	org.lwjgl.util.Timer t;

	/**
	 * Creates a LWTimer instance.
	 * Typically this should not be called by the user,
	 * instead call <code>Timer.createTimer()</code>
	 * 
	 */
	public LWTimer() {
		t = new org.lwjgl.util.Timer();
	}

	public long coerceDeltaTime(long dwt) { return dwt; }

	public long getAbsoluteWallTime(long lastAbsoluteTime) {
		org.lwjgl.util.Timer.tick();
		return (long) (t.getTime() * GameClock.NANOS_PER_SECOND);
	}


}