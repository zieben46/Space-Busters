package jig.engine.lwjgl;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.color.ColorSpace;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.ComponentColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.PixelGrabber;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.util.Hashtable;

import jig.engine.ResourceFactory;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

/**
 * 
 * OpenGL uses an RGBA image format. Since the images that are 
 * loaded from disk may not match this format this loader introduces
 * an intermediate image which the source image is copied into.
 * In turn, this image is used as source for the OpenGL texture.
 *
 * This version of the texture loader creates one large texture
 * out of a spritesheet and restricts the mapping to an individual
 * sprite during the rendering phase in the Texture class. This is
 * a more efficient approach.
 * 
 * @author Andrew Nierman
 * 
 * TODO this implementation is not yet complete, and is not currently in use
 */
class CachingTextureLoader {
    //The color model for the GL image
    private ColorModel glColorModel;

    //The color model including alpha for the GL image
    private ColorModel glAlphaColorModel;
    
    /** 
     * Create a new texture loader.
     *
     */
    public CachingTextureLoader() {
        glAlphaColorModel = new ComponentColorModel(
        		ColorSpace.getInstance(ColorSpace.CS_sRGB),
                                            new int[] {8, 8, 8, 8},
                                            true,
                                            false,
                                            ComponentColorModel.TRANSLUCENT,
                                            DataBuffer.TYPE_BYTE);
                                            
        glColorModel = new ComponentColorModel(
        		ColorSpace.getInstance(ColorSpace.CS_sRGB),
                                            new int[] {8, 8, 8, 0},
                                            false,
                                            false,
                                            ComponentColorModel.OPAQUE,
                                            DataBuffer.TYPE_BYTE);
    }
    
    private int createTextureID() {
       IntBuffer buffer = BufferUtils.createIntBuffer(1);
       GL11.glGenTextures(buffer);
       return buffer.get(0);
    }
    
	//transparency, w, h, xoffset, yoffset);
	
    public OffsetTexture getTexture(BufferedImage bufferedImage,
    		int transparency, int subImageWidth, int subImageHeight,
    		int xOffset, int yOffset) {
    	
    	int target = GL11.GL_TEXTURE_2D;
        int dstPixelFormat = GL11.GL_RGBA;
        int minFilter = GL11.GL_LINEAR; //GL_NEAREST is more efficient
        int magFilter = GL11.GL_LINEAR; //GL_NEAREST is more efficient
        //although for us, the texture will almost always be the same
        //size as the image/sprite and filtering won't be used
        
        int srcPixelFormat = 0;
        
        // create the texture ID for this texture 
        int textureID = createTextureID();
        
        // bind this texture 
        GL11.glBindTexture(target, textureID); 
        
        if (bufferedImage.getColorModel().hasAlpha()) {
            srcPixelFormat = GL11.GL_RGBA;
        } else {
            srcPixelFormat = GL11.GL_RGB;
        }

        OffsetTexture texture = new OffsetTexture(target, textureID);
        texture.setFullImageWidth(bufferedImage.getWidth());
        texture.setFullImageHeight(bufferedImage.getHeight());
        texture.setSubImageWidth(subImageWidth);
        texture.setSubImageHeight(subImageHeight);
        texture.setSubImageXOffset(xOffset);
        texture.setSubImageYOffset(yOffset);


        // convert that image into a byte buffer of texture data 
        ByteBuffer textureBuffer = convertImageData(bufferedImage,
        		texture, subImageWidth, subImageHeight, xOffset, yOffset); 

//        ByteBuffer textureBuffer = convertImageToByteBuffer(bufferedImage,
//        	xOffset, yOffset, width, height, false);
        	
        if (target == GL11.GL_TEXTURE_2D) {
            GL11.glTexParameteri(target, GL11.GL_TEXTURE_MIN_FILTER, minFilter);
            GL11.glTexParameteri(target, GL11.GL_TEXTURE_MAG_FILTER, magFilter);
        }

        // produce a texture from the byte buffer
        GL11.glTexImage2D(target, 
                      0, 
                      dstPixelFormat, 
                      get2Fold(bufferedImage.getWidth()), 
                      get2Fold(bufferedImage.getHeight()), 
                      0, 
                      srcPixelFormat, 
                      GL11.GL_UNSIGNED_BYTE, 
                      textureBuffer);
        
        return texture; 
    } 
    
    /**
     * Get the closest greater power of 2 to the fold number
     * 
     * @param fold The target number
     * @return The power of 2
     */
    private int get2Fold(int fold) {
        int ret = 2;
        while (ret < fold) {
            ret *= 2;
        }
        return ret;
    } 
    
    /**
     * Convert the buffered image to a texture
     *
     * @param bufferedImage The image to convert to a texture
     * @param texture The texture to store the data into
     * @param width width
     * @param height height
     * @param xOffset xOffset
     * @param yOffset yOffset
     * @return A buffer containing the data
     */
    private ByteBuffer convertImageData(final BufferedImage bufferedImage,
    		final OffsetTexture texture, 
    		final int width, final int height,
    		final int xOffset, final int yOffset) {
    	
        ByteBuffer imageBuffer = null; 
        WritableRaster raster;
        BufferedImage texImage;
        
        int fullTextureWidth = 2;
        int fullTextureHeight = 2;
        
        // find the closest power of 2 for the width and height
        // of the produced texture
        // note, we're using the full image (spritesheet) dimensions here
        // not just the sub image (sprite) dimensions
        while (fullTextureWidth < bufferedImage.getWidth()) {
            fullTextureWidth *= 2;
        }
        while (fullTextureHeight < bufferedImage.getHeight()) {
            fullTextureHeight *= 2;
        }
        
        // set the width and height of the texture
//        texture.setFullTextureWidth(fullTextureWidth);
//        texture.setFullTextureHeight(fullTextureHeight);
        
        // create a raster that can be used by OpenGL as a source for a texture
        if (bufferedImage.getColorModel().hasAlpha()) {
            raster = Raster.createInterleavedRaster(
            		DataBuffer.TYPE_BYTE, fullTextureWidth, fullTextureHeight, 4, null);
            texImage = new BufferedImage(
            		glAlphaColorModel, raster, false, new Hashtable<Object,Object>());
        } else {
            raster = Raster.createInterleavedRaster(
            		DataBuffer.TYPE_BYTE, fullTextureWidth, fullTextureHeight, 3, null);
            texImage = new BufferedImage(
            		glColorModel, raster, false, new Hashtable<Object,Object>());
        }
        
        // copy the source image into the produced image
        Graphics g = texImage.getGraphics();
        g.setColor(new Color(0f, 0f, 0f, 0f));
        g.fillRect(0, 0, fullTextureWidth, fullTextureHeight);
        g.drawImage(bufferedImage, 0, 0, null);
        //g.drawImage(bufferedImage, 0, 0, new Color(0f, 0f, 0f, 0f), null);
        
        // build a byte buffer from the temporary image 
        // that be used by OpenGL to produce a texture.
        byte[] data = ((DataBufferByte) texImage.getRaster().getDataBuffer()).getData(); 

        imageBuffer = ByteBuffer.allocateDirect(data.length); 
        imageBuffer.order(ByteOrder.nativeOrder()); 
        imageBuffer.put(data, 0, data.length); 
        imageBuffer.flip();
        
        return imageBuffer; 
    }
    
    ////////////////
    ////////////////
    ////////////////    
    
    public ByteBuffer convertImageToByteBuffer(Image image,
    		int xOffset, int yOffset, int width, int height, boolean flip) {

    	//store pixels in default Java ARGB format
    	int[] pixels = getImagePixels(image, xOffset, yOffset,
    			width, height);

    	//store bytes in GL_RGBA format
    	ByteBuffer pixelBuffer = convertImagePixels(pixels,
    			width, height, true);
    	
    	return pixelBuffer;
    	
    }

    public ByteBuffer convertImageToByteBuffer(Image image) {
    	return convertImageToByteBuffer(image, 0, 0,
    			image.getWidth(null), image.getHeight(null), true);
    }

    public int[] getImagePixels(Image image) {
    	return getImagePixels(image, 0, 0,
    			image.getWidth(null), image.getHeight(null));
    }
    
    /**
     * 
     * @param image a Java Image object representing a loaded image
     * @return an integer array in the Java int ARGB format
     */
    public int[] getImagePixels(Image image, int xOffset, int yOffset,
    		int w, int h) {

    	int[] pixels = new int[w * h];
    	
    	PixelGrabber p = new PixelGrabber(image, xOffset, yOffset,
    			w, h, pixels, 0, w);
    	boolean successful = false;
    	
    	try {
			successful = p.grabPixels();
		} catch (InterruptedException e) {
			//e.printStackTrace();
			ResourceFactory.getJIGLogger().severe("PixelGrabber interrupted.");
			return null;
		}

		if (successful) {
			return pixels;
		} else {
			return null;
		}
    }

    /**
     * Convert ARGB pixels to a ByteBuffer containing RGBA pixels.<BR>
     * Can be drawn in ORTHO mode using:<BR>
     *         GL.glDrawPixels(imgW, imgH, GL.GL_RGBA, GL.GL_UNSIGNED_BYTE, byteBuffer); <BR>
     * If flipVertically is true, pixels will be flipped vertically (for OpenGL coord system).
     * @param imgFilename
     * @return ByteBuffer
     */
    public static ByteBuffer convertImagePixels(int[] jpixels, int imgw, int imgh, boolean flipVertically) {
        byte[] bytes;     // will hold pixels as RGBA bytes

        if (flipVertically) {
            jpixels = flipPixels(jpixels, imgw, imgh); // flip Y axis
        }

        bytes = convertARGBtoRGBA(jpixels);

        ByteBuffer buffer = BufferUtils.createByteBuffer(bytes.length);
        buffer.put(bytes);
        buffer.flip();
        
        return buffer;
    }
    
    public static int[] flipPixels(int[] imgPixels, int imgw, int imgh) {
        int[] flippedPixels = null;
        
        if (imgPixels != null) {
            flippedPixels = new int[imgw * imgh];
            for (int y = 0; y < imgh; y++) {
                for (int x = 0; x < imgw; x++) {
                    flippedPixels[ ( (imgh - y - 1) * imgw) + x] =
                    	imgPixels[ (y * imgw) + x];
                }
            }
        }

        return flippedPixels;
    }

    /**
     * Convert pixels from java default ARGB int format to byte array in RGBA format.
     * @param jpixels
     * @return
     */
    public static byte[] convertARGBtoRGBA(int[] jpixels) {
        byte[] bytes = new byte[jpixels.length*4];  // will hold pixels as RGBA bytes
        int p, r, g, b, a;
        int j=0;

        for (int i = 0; i < jpixels.length; i++) {
            //int outPixel = 0x00000000; // AARRGGBB
            p = jpixels[i];
            a = (p >> 24) & 0xFF;  // get pixel bytes in ARGB order
            r = (p >> 16) & 0xFF;
            g = (p >> 8) & 0xFF;
            b = (p >> 0) & 0xFF;
            bytes[j+0] = (byte)r;  // fill in bytes in RGBA order
            bytes[j+1] = (byte)g;
            bytes[j+2] = (byte)b;
            bytes[j+3] = (byte)a;
            j += 4;
        }

        return bytes;
    }
    
}
