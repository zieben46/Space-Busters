package jig.engine.lwjgl;

import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import jig.engine.KeyInfo;
import jig.engine.ResourceFactory;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;

/**
 * A pollable keyboard class for the LWJGL backend.
 * 
 * @author Andrew Nierman
 *
 */
class LWKeyboard implements jig.engine.Keyboard {
	private static final char CONSOLE_KEY = '`';
	
	private static Map<Integer, Integer> javaToLW =
		new HashMap<Integer, Integer>();
	private static Map<Integer, Integer> lwToJava =
		new HashMap<Integer, Integer>();
	private LWGameFrame gameFrame;
	private boolean consumeForConsole;
	
	// a queue of key presses/releases that were not consumed for the console:
	private LinkedList<KeyInfo> queue = new LinkedList<KeyInfo>();
	
	/**
	 * Create a new keyboard object. We need to pass in the game frame for use
	 * when we are displaying the console.
	 * 
	 * @param gameFrame the current game frame
	 */
	public LWKeyboard(final LWGameFrame gameFrame) {
		this.gameFrame = gameFrame;
		consumeForConsole = false;

		initializeMappings();
		try {
			Keyboard.create();
		} catch (LWJGLException e) {
			// e.printStackTrace();
			ResourceFactory.getJIGLogger().severe(
					"A Keyboard object could not be created. "
							+ "Was the graphics frame created first?");
		}
	}

	
	/**
	 * Gets the next keyboard event.
	 * 
	 * @return a KeyInfo object containing information about the key event
	 */
	public KeyInfo get() {
		return queue.poll();		
	}

	/**
	 * Determines if a key is pressed.
	 * 
	 * @param key the key to check
	 * @return true iff the key is currently pressed
	 */
	public boolean isPressed(final int key) {
		if (consumeForConsole) {
			return false;
		}
		
//		if (!javaToLW.containsKey(key)) {
//			ResourceFactory.getJIGLogger().info(
//					"the key w/ java code=" + key
//							+ " does not have an LWJGL Mapping");
//
//			return false;
//		}

		return org.lwjgl.input.Keyboard.isKeyDown(javaToLW.get(key));
	}

	/**
	 * Poll the keyboard, updating its status.
	 */
	public void poll() {
		Keyboard.poll();
        
		if (!Keyboard.next()) {
			return;
		}

		int keyCode = Keyboard.getEventKey();

//		if (!lwToJava.containsKey(keyCode)) {
//			ResourceFactory.getJIGLogger().info(
//					"the key w/ lwjgl code=" + keyCode
//							+ " does not have a Java Mapping");
//
//			return;
//		}

		int javaKeyCode = lwToJava.get(keyCode);
		
		char character = Keyboard.getEventCharacter();
		boolean pressed = Keyboard.getEventKeyState();

		if (character == CONSOLE_KEY) {
			if (pressed) {
				consumeForConsole = gameFrame.getConsole().toggleDisplay();
			}
		}
		// with lwjgl there will not be a character code associated
		// with the arrow keys, shift, etc., but it will get passed along as
		// a value of zero here, so check for that,
		// TODO it's also possible for
		// the escape character (with a positive character value), to get 
		// appended to the prompt, but the console itself should probably check
		// for these non-printable characters getting added to the current line
		else if (consumeForConsole && pressed && character != 0) {
			gameFrame.getConsole().appendToPrompt(character);			
		} else {
			KeyInfo key = new KeyInfo(character, javaKeyCode,
					pressed ? KeyInfo.State.PRESSED : KeyInfo.State.RELEASED);
			queue.add(key);
		}
 	}

	/**
	 * Create mappings from the LWJGL key events to the Java key events,
	 * and vice versa.
	 */
	private void initializeMappings() {
		// A bit painful to put all of these key code mappings in manually
		storeMappings(KeyEvent.VK_UNDEFINED, Keyboard.KEY_NONE);

		storeMappings(KeyEvent.VK_ESCAPE, Keyboard.KEY_ESCAPE);
		storeMappings(KeyEvent.VK_BACK_QUOTE, Keyboard.KEY_GRAVE);
		storeMappings(KeyEvent.VK_SPACE, Keyboard.KEY_SPACE);
		storeMappings(KeyEvent.VK_TAB, Keyboard.KEY_TAB);

		storeMappings(KeyEvent.VK_LEFT, Keyboard.KEY_LEFT);
		storeMappings(KeyEvent.VK_RIGHT, Keyboard.KEY_RIGHT);
		storeMappings(KeyEvent.VK_UP, Keyboard.KEY_UP);
		storeMappings(KeyEvent.VK_DOWN, Keyboard.KEY_DOWN);

		storeMappings(KeyEvent.VK_A, Keyboard.KEY_A);
		storeMappings(KeyEvent.VK_B, Keyboard.KEY_B);
		storeMappings(KeyEvent.VK_C, Keyboard.KEY_C);
		storeMappings(KeyEvent.VK_D, Keyboard.KEY_D);
		storeMappings(KeyEvent.VK_E, Keyboard.KEY_E);
		storeMappings(KeyEvent.VK_F, Keyboard.KEY_F);
		storeMappings(KeyEvent.VK_G, Keyboard.KEY_G);
		storeMappings(KeyEvent.VK_H, Keyboard.KEY_H);
		storeMappings(KeyEvent.VK_I, Keyboard.KEY_I);
		storeMappings(KeyEvent.VK_J, Keyboard.KEY_J);
		storeMappings(KeyEvent.VK_K, Keyboard.KEY_K);
		storeMappings(KeyEvent.VK_L, Keyboard.KEY_L);
		storeMappings(KeyEvent.VK_M, Keyboard.KEY_M);
		storeMappings(KeyEvent.VK_N, Keyboard.KEY_N);
		storeMappings(KeyEvent.VK_O, Keyboard.KEY_O);
		storeMappings(KeyEvent.VK_P, Keyboard.KEY_P);
		storeMappings(KeyEvent.VK_Q, Keyboard.KEY_Q);
		storeMappings(KeyEvent.VK_R, Keyboard.KEY_R);
		storeMappings(KeyEvent.VK_S, Keyboard.KEY_S);
		storeMappings(KeyEvent.VK_T, Keyboard.KEY_T);
		storeMappings(KeyEvent.VK_U, Keyboard.KEY_U);
		storeMappings(KeyEvent.VK_V, Keyboard.KEY_V);
		storeMappings(KeyEvent.VK_W, Keyboard.KEY_W);
		storeMappings(KeyEvent.VK_X, Keyboard.KEY_X);
		storeMappings(KeyEvent.VK_Y, Keyboard.KEY_Y);
		storeMappings(KeyEvent.VK_Z, Keyboard.KEY_Z);

		storeMappings(KeyEvent.VK_0, Keyboard.KEY_0);
		storeMappings(KeyEvent.VK_1, Keyboard.KEY_1);
		storeMappings(KeyEvent.VK_2, Keyboard.KEY_2);
		storeMappings(KeyEvent.VK_3, Keyboard.KEY_3);
		storeMappings(KeyEvent.VK_4, Keyboard.KEY_4);
		storeMappings(KeyEvent.VK_5, Keyboard.KEY_5);
		storeMappings(KeyEvent.VK_6, Keyboard.KEY_6);
		storeMappings(KeyEvent.VK_7, Keyboard.KEY_7);
		storeMappings(KeyEvent.VK_8, Keyboard.KEY_8);
		storeMappings(KeyEvent.VK_9, Keyboard.KEY_9);

		storeMappings(KeyEvent.VK_MINUS, Keyboard.KEY_MINUS);
		storeMappings(KeyEvent.VK_EQUALS, Keyboard.KEY_EQUALS);

		storeMappings(KeyEvent.VK_COMMA, Keyboard.KEY_COMMA);
		storeMappings(KeyEvent.VK_PERIOD, Keyboard.KEY_PERIOD);
		storeMappings(KeyEvent.VK_SLASH, Keyboard.KEY_SLASH);
		storeMappings(KeyEvent.VK_SEMICOLON, Keyboard.KEY_SEMICOLON);
		storeMappings(KeyEvent.VK_QUOTE, Keyboard.KEY_APOSTROPHE);
		storeMappings(KeyEvent.VK_BRACELEFT, Keyboard.KEY_LBRACKET);
		storeMappings(KeyEvent.VK_BRACERIGHT, Keyboard.KEY_RBRACKET);
		storeMappings(KeyEvent.VK_BACK_SLASH, Keyboard.KEY_BACKSLASH);

		storeMappings(KeyEvent.VK_DELETE, Keyboard.KEY_DELETE);
		storeMappings(KeyEvent.VK_ENTER, Keyboard.KEY_RETURN);
		storeMappings(KeyEvent.VK_BACK_SPACE, Keyboard.KEY_BACK);

		storeMappings(KeyEvent.VK_NUMPAD0, Keyboard.KEY_NUMPAD0);
		storeMappings(KeyEvent.VK_NUMPAD1, Keyboard.KEY_NUMPAD1);
		storeMappings(KeyEvent.VK_NUMPAD2, Keyboard.KEY_NUMPAD2);
		storeMappings(KeyEvent.VK_NUMPAD3, Keyboard.KEY_NUMPAD3);
		storeMappings(KeyEvent.VK_NUMPAD4, Keyboard.KEY_NUMPAD4);
		storeMappings(KeyEvent.VK_NUMPAD5, Keyboard.KEY_NUMPAD5);
		storeMappings(KeyEvent.VK_NUMPAD6, Keyboard.KEY_NUMPAD6);
		storeMappings(KeyEvent.VK_NUMPAD7, Keyboard.KEY_NUMPAD7);
		storeMappings(KeyEvent.VK_NUMPAD8, Keyboard.KEY_NUMPAD8);
		storeMappings(KeyEvent.VK_NUMPAD9, Keyboard.KEY_NUMPAD9);

		// other lwjgl numpad keys:
		// KEY_MULTIPLY
		// KEY_SUBTRACT
		// KEY_ADD
		// KEY_DECIMAL
		// KEY_NUMPADEQUALS
		// KEY_NUMPADENTER
		// KEY_NUMPADCOMMA
		// KEY_DIVIDE

		storeMappings(KeyEvent.VK_NUM_LOCK, Keyboard.KEY_NUMLOCK);
		storeMappings(KeyEvent.VK_PAUSE, Keyboard.KEY_PAUSE);

		storeMappings(KeyEvent.VK_F1, Keyboard.KEY_F1);
		storeMappings(KeyEvent.VK_F2, Keyboard.KEY_F2);
		storeMappings(KeyEvent.VK_F3, Keyboard.KEY_F3);
		storeMappings(KeyEvent.VK_F4, Keyboard.KEY_F4);
		storeMappings(KeyEvent.VK_F5, Keyboard.KEY_F5);
		storeMappings(KeyEvent.VK_F6, Keyboard.KEY_F6);
		storeMappings(KeyEvent.VK_F7, Keyboard.KEY_F7);
		storeMappings(KeyEvent.VK_F8, Keyboard.KEY_F8);
		storeMappings(KeyEvent.VK_F9, Keyboard.KEY_F9);
		storeMappings(KeyEvent.VK_F10, Keyboard.KEY_F10);
		storeMappings(KeyEvent.VK_F11, Keyboard.KEY_F11);
		storeMappings(KeyEvent.VK_F12, Keyboard.KEY_F12);
		storeMappings(KeyEvent.VK_F13, Keyboard.KEY_F13);
		storeMappings(KeyEvent.VK_F14, Keyboard.KEY_F14);
		storeMappings(KeyEvent.VK_F15, Keyboard.KEY_F15);
		// storeMappings(KeyEvent.VK_F16, );
		// storeMappings(KeyEvent.VK_F17, );
		// storeMappings(KeyEvent.VK_F18, );
		// storeMappings(KeyEvent.VK_F19, );
		// storeMappings(KeyEvent.VK_F20, );
		// storeMappings(KeyEvent.VK_F21, );
		// storeMappings(KeyEvent.VK_F22, );
		// storeMappings(KeyEvent.VK_F23, );
		// storeMappings(KeyEvent.VK_F24, );

		lwToJava.put(Keyboard.KEY_LSHIFT, KeyEvent.VK_SHIFT);
		lwToJava.put(Keyboard.KEY_RSHIFT, KeyEvent.VK_SHIFT);
		// TODO need to fix this:
		javaToLW.put(KeyEvent.VK_SHIFT, Keyboard.KEY_LSHIFT);

		lwToJava.put(Keyboard.KEY_LCONTROL, KeyEvent.VK_CONTROL);
		lwToJava.put(Keyboard.KEY_RCONTROL, KeyEvent.VK_CONTROL);
		// TODO need to fix this:
		javaToLW.put(KeyEvent.VK_CONTROL, Keyboard.KEY_LCONTROL);

		lwToJava.put(Keyboard.KEY_LMENU, KeyEvent.VK_ALT);
		lwToJava.put(Keyboard.KEY_RMENU, KeyEvent.VK_ALT);
		// TODO need to fix this:
		javaToLW.put(KeyEvent.VK_ALT, Keyboard.KEY_LMENU);

	}

	/**
	 * Store a mapping for both java to lwjgl, and lwjgl to java.
	 * 
	 * @param j2d the java key event code
	 * @param lw the lwjgl key event code
	 */
	private void storeMappings(final int j2d, final int lw) {
		javaToLW.put(j2d, lw);
		lwToJava.put(lw, j2d);
	}
}
