package jig.engine.lwjgl;

import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

import jig.engine.ImageResource;
import jig.engine.RenderingContext;

import org.lwjgl.opengl.GL11;

/**
 * This class is responsible for keeping track of a given OpenGL texture 
 * and for calculating the texturing mapping coordinates of the full image.
 * 
 * The texture bound to this object is an entire spritesheet, and the
 * state of the object restricts the mapping to a single sprite within
 * that sheet in the rendering phase.
 *
 * @author Andrew Nierman
 * 
 * TODO this implementation is not yet complete, and is not currently in use
 */
class OffsetTexture implements ImageResource {
	
    //The GL target type
    private int target; 
    //The GL texture ID
    private int textureID;

    //The dimensions of the sprite
    private int subImageWidth;
    private int subImageHeight;
    
    //The offset of the sprite within a sprite sheet
    private int subImageXOffset;
    private int subImageYOffset;
    
    //The dimensions of the sprite sheet
    private int fullImageWidth;
    private int fullImageHeight;
    
    //The dimensions of the texture (for the whole sprite sheet)
    //This will be >= the size of the sprite sheet (they will be
    //the same size if the sprite sheet dimensions are a power of 2)
    //private int fullTextureWidth;
    //private int fullTextureHeight;
    
    
    /**
     * Create a new texture
     *
     * @param target The GL target 
     * @param textureID The GL texture ID
     */
    public OffsetTexture(final int target, final int textureID) {
//    		int fullTextureWidth, int fullTextureHeight,
//    		int fullImageWidth, int fullImageHeight,
//    		int subImageWidth, int subImageHeight,
//    		int subImageXOffset, int subImageYOffset)
    	this.target = target;
    	this.textureID = textureID;
    	
//    	this.fullTextureWidth = fullTextureWidth;
//    	this.fullTextureHeight = fullTextureHeight;
//    	this.fullImageWidth = fullImageWidth;
//    	this.fullImageHeight = fullImageHeight;
//    	this.subImageWidth = subImageWidth;
//    	this.subImageXOffset = subImageXOffset;
//    	this.subImageYOffset = subImageYOffset;
    }
    
	public int getWidth() {
		return subImageWidth;
	}
    
	public int getHeight() {
		return subImageHeight;
	}


	public void render(RenderingContext rc, AffineTransform at) {
		GL11.glPushMatrix();
		
		// bind to the appropriate texture for this sprite
		bind();
    
		// translate to the right location and prepare to draw
		//GL11.glTranslatef(x, y, 0);		
    	//GL11.glColor3f(1, 1, 1);
    	
    	rc.transform(at);
		

		// float x0 = xToTex(subImageXOffset);
		// float y0 = yToTex(subImageYOffset);
		//    	
		// float x1 = xToTex(subImageXOffset + subImageWidth);
		// float y1 = yToTex(subImageYOffset + subImageHeight);
    	
		// draw a quad textured to match the sprite
    	GL11.glBegin(GL11.GL_QUADS);
    	{
		      GL11.glTexCoord2f(xToTex(subImageXOffset),
		    		  yToTex(subImageYOffset));
		      GL11.glVertex2f(0, 0);
		      
		      GL11.glTexCoord2f(xToTex(subImageXOffset + subImageWidth),
		    		  yToTex(subImageYOffset));
		      GL11.glVertex2f(subImageWidth, 0);
		      
		      GL11.glTexCoord2f(xToTex(subImageXOffset + subImageWidth),
		    		  yToTex(subImageYOffset + subImageHeight));
		      GL11.glVertex2f(subImageWidth, subImageHeight);
		      
		      GL11.glTexCoord2f(xToTex(subImageXOffset),
		    		  yToTex(subImageYOffset + subImageHeight));
		      GL11.glVertex2f(0, subImageHeight);
    	}
		GL11.glEnd();
		
		// restore the model view matrix to prevent contamination
		GL11.glPopMatrix();
		
		//TODO is this needed:
		//Display.update();
    }

    private float xToTex(int x) {
    	return (1.0f * x / fullImageWidth);
    }
    
    private float yToTex(int y) {
    	return (1.0f * y / fullImageHeight);
    }
    
    /**
     * Bind the specified GL context to a texture
     *
     * @param gl The GL context to bind to
     */
    private void bind() {
      GL11.glBindTexture(target, textureID); 
    }

    
	public void setFullImageHeight(int fullImageHeight) {
		this.fullImageHeight = fullImageHeight;
	}

	public void setFullImageWidth(int fullImageWidth) {
		this.fullImageWidth = fullImageWidth;
	}

//	public void setFullTextureHeight(int fullTextureHeight) {
//		this.fullTextureHeight = fullTextureHeight;
//	}
//
//	public void setFullTextureWidth(int fullTextureWidth) {
//		this.fullTextureWidth = fullTextureWidth;
//	}

	public void setSubImageHeight(int subImageHeight) {
		this.subImageHeight = subImageHeight;
	}

	public void setSubImageWidth(int subImageWidth) {
		this.subImageWidth = subImageWidth;
	}

	public void setSubImageXOffset(int subImageXOffset) {
		this.subImageXOffset = subImageXOffset;
	}

	public void setSubImageYOffset(int subImageYOffset) {
		this.subImageYOffset = subImageYOffset;
	}
	/**
	 * TODO: Incomplete!
	 */
	public void draw(Graphics2D g, AffineTransform at) {
		
	}

    /*
    public void render( RenderingContext rc, double x, double y) {
    	System.out.println( "Rendering Sprite: " + Display.isCreated());
    	System.out.println( "rc: x: y: = " + rc + " : " +  x + " : "+ y);
    	GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GL11.glMatrixMode(GL11.GL_MODELVIEW);
		GL11.glLoadIdentity();

    	GL11.glPushMatrix();
		
		// bind to the appropriate texture for this sprite
		bind();
    
		// translate to the right location and prepare to draw
		GL11.glTranslatef((float)x, (float)y, 0.0f);		
    	GL11.glColor3f(1,1,1);
		
		// draw a quad textured to match the sprite
    	GL11.glBegin(GL11.GL_QUADS);
		{
	      GL11.glTexCoord2f(0, 0);
	      GL11.glVertex2f(0, 0);
	      GL11.glTexCoord2f(0, getHeightRatio());
	      GL11.glVertex2f(0, getHeight());
	      GL11.glTexCoord2f(getWidthRatio(), getHeightRatio());
	      GL11.glVertex2f(getWidth(),getHeight());
	      GL11.glTexCoord2f(getWidthRatio(), 0);
	      GL11.glVertex2f(getWidth(),0);
		}
		GL11.glEnd();
		
		// restore the model view matrix to prevent contamination
		GL11.glPopMatrix();
		Display.update();
    }
    */
}
