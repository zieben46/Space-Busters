package jig.engine.lwjgl;

import java.awt.Point;

import jig.engine.CursorResource;
import jig.engine.ResourceFactory;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

/**
 * A concrete mouse class for the LWJGL backend.
 * 
 * @author Andrew Nierman
 *
 */
class LWMouse implements jig.engine.Mouse {
	private CursorResource cursor;
	private LWGameFrame gameFrame;

	/**
	 * Create a new mouse object. We need a reference to the game frame to
	 * interpret the mouse position in full screen and windowed mode.
	 * 
	 * @param gf the current game frame
	 */
	public LWMouse(final LWGameFrame gf) {
		try {
			Mouse.create();
		} catch (LWJGLException e) {
			// e.printStackTrace();
			ResourceFactory.getJIGLogger().severe(
					"A Mouse object could not be created. "
							+ "Was the graphics frame created first?");
		}
		gameFrame = gf;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isLeftButtonPressed() {
		Mouse.poll();
		return Mouse.isButtonDown(0);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isRightButtonPressed() {
		Mouse.poll();
		return Mouse.isButtonDown(1);
	}

	/**
	 * {@inheritDoc}
	 */
	public Point getLocation() {
		Mouse.poll();

		// there are a few issues with mouse positioning with LWJGL:
		
		// case #1. the y coordinates are flipped when compared to the AWTMouse
		// (and our coordinate system) so we need to use the screenHeight to
		// flip the Y component
		
		// case #2. in the case above, we will return accurate positioning when
		// the screen is in windowed mode, but if we go to full screen, the
		// mouse will be returning an absolute position, based on the actual
		// pixels, whereas the game window may be "stretched" to fit on the
		// screen and might have different dimensions, we need to scale the
		// mouse coordinates to the original dimensions of the game frame
		
		// when the window is toggled between full screen and windowed mode,
		// the windowPixelWidth and windowPixelHeight variables are updated\
		// in the LWGameFrame class
		
		if (Display.isFullscreen()) {
			double widthRatio =
				1.0 * gameFrame.getWidth()
				/ gameFrame.getFullscreenPixelWidth();
			double heightRatio =
				1.0 * gameFrame.getHeight()
				/ gameFrame.getFullscreenPixelHeight();
			
			int x = (int) (Mouse.getX() * widthRatio);
			int y = (int) (Mouse.getY() * heightRatio);
			
			return new Point(x, (gameFrame.getHeight() - 1) - y);
			
		} else {
			// in windowed mode, just flipe the y coordinate
			return new Point(Mouse.getX(),
					(gameFrame.getHeight() - 1) - Mouse.getY());
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void setCursor(final CursorResource c) {
		try {
			cursor = c;
			// DESIGN should avoid this downcast if possible
			Mouse.setNativeCursor(((LWCursor)c).getLwjglCursor());
		} catch (LWJGLException e) {
			ResourceFactory.getJIGLogger().warning("Cursor could not be set.");
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void resetCursor() {
		try {
			cursor = null;
			Mouse.setNativeCursor(null);
		} catch (LWJGLException e) {
			ResourceFactory.getJIGLogger()
					.warning("Cursor could not be reset.");
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isCursorSet() {
		return Mouse.getNativeCursor() != null;
	}

	/**
	 * {@inheritDoc}
	 */
	public CursorResource getCursor() {
		return cursor;
	}
}
